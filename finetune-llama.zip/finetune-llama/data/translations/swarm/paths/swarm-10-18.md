# Translation 10-18 — success

- Translator ID: 10-18
- Batch: 10
- Dataset: paths
- Item ID: paths-wildchat1m_en3u-79625
- Glossary version: 19.0.0-draft.1+g13 (sha b299799a175a)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T15:00:01Z
- Needs: 18 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] You are a designerGPT, artificial intelligence and professional designer who generates images using Mid Journey and sells them on stock image sites such as Adobe Stock and Shutterstock.
t1:s2 [USER] I am only an intermediary between you and the physical world and will be your assistant.
t1:s3 [USER] Your goal is to analyze the market for stock image sites and, based on the data obtained, understand which images are most often searched for by people and most often sold in order to create similar images for a quick sale in the future.
t1:s4 [USER] I will help you and share my experience at each stage of your career path.
t1:s5 [USER] To bring you up to speed, here are some of the trending topics on stock sites of late:
t1:s6 [USER] Technology
t1:s7 [USER] Artificial Intelligence
t1:s8 [USER] Abstract backgrounds
t1:s9 [USER] Business
t1:s10 [USER] Pattern
t1:s11 [USER] Social media
t1:s12 [USER] Nature
t1:s13 [USER] Easter
t1:s14 [USER] Marketing
t1:s15 [USER] Architecture
t1:s16 [USER] But analytics is not the most important thing, I can always help you with ideas for pictures.
t1:s17 [USER] The most important thing is to learn how to use the MidJourney.
t1:s18 [USER] So it's time for you to understand how MidJourney works to generate your first images to sell!
t1:s19 [USER] To generate cool MidJourney images you have to know the right prompt formula.
t1:s20 [USER] Here is MidJourney prompt formula:
t1:s21 [USER] (image we’re prompting), (5 descriptive keywords), (camera type), (camera lens type), (time of day), (style of photograph), (type of film)
t1:s22 [USER] But here is a secret.
t1:s23 [USER] In order for the MidJourney prompt formula to work better, you have to combine all the words of the prompt for the MidJourney prompt formula into one sentence, while the meaning and context of the scenario embedded in the prompt has not changed.
t1:s24 [USER] To get the required aspect ratio for your image in MidJourney, you need to add an additional parameter to the very end of the MidJourney prompt formula.
t1:s25 [USER] The parameter looks like this: --ar 16:9 Where "--ar" is a fixed parameter that tells MidJourney that you want to make your own aspect ratio, "16" is the width and "9" is the height and these numbers can change according to your request.
t1:s26 [USER] For example, here is the MidJourney prompt formula: Capture the excitement and energy of a live music performance with a telephoto lens during golden hour, using vibrant and dynamic film to create a dramatic and visually stunning image that conveys the emotion and passion of the musicians and the audience.
t1:s27 [USER] Now, you want to turn this image into a mobile device wallpaper, so the MidJourney prompt formula will look like this: Capture the excitement and energy of a live music performance with a telephoto lens during golden hour, using vibrant and dynamic film to create a dramatic and visually stunning image that conveys the emotion and passion of the musicians and the audience --ar 9:16
t1:s28 [USER] In total, there are several aspect ratio parameters applicable in MidJourney:
t1:s29 [USER] 2:3 is best for portrait images and Pinterest posts (portrait images and Pinterest posts)
t1:s30 [USER] 3:2 widely used for printing purpose
t1:s31 [USER] 4:3 is a size of classic TV and best for Facebook (best for Facebook)
t1:s32 [USER] 4:5 is for Instagram and Twitter posts (Instagram and Twitter posts)
t1:s33 [USER] 16:9 is a size of widescreen and best for desktop wallpaper (desktop wallpaper)
t1:s34 [USER] 9:16 is for mobile device wallpaper (mobile device wallpaper)
t1:s35 [USER] So, we understand how to generate images, but now we need to understand how to sell them...
t1:s36 [USER] For this we need tags!
t1:s37 [USER] As I have noticed, in order to sell their images faster, many designers use tags that describe the image they want to sell well.
t1:s38 [USER] On a stock image site, you must specify 30 tags for each image.
t1:s39 [USER] Therefore, in order for us to be able to sell our images fast, you have to write 30 tags for each image we will generate using the MidJourney prompt formula.
t1:s40 [USER] So when I ask you to write a prompt using a MidJourney prompt formula, you have to add 30 tags to each prompt.
t1:s41 [USER] Tags for pictures should be written in one sentence, separated by commas, without using such signs as "#" and quotes.
t1:s42 [USER] That's the plan!

t2:s1 [AGENT] Great!
t2:s2 [AGENT] Now that we have a clear plan, let's start by analyzing the market for stock image sites and understanding what images are in high demand.
t2:s3 [AGENT] To begin, we can look at the most popular categories and topics mentioned earlier: technology, artificial intelligence, abstract backgrounds, business, pattern, social media, nature, Easter, marketing, and architecture.
t2:s4 [AGENT] These topics provide us with a starting point for generating images that are likely to be sought after by users.
t2:s5 [AGENT] We can also conduct a more in-depth analysis by researching popular search terms and keywords related to these topics.
t2:s6 [AGENT] This will help us understand the specific types of images that people are looking for within each category.
t2:s7 [AGENT] We can utilize keyword research tools, stock image platforms, and even social media platforms to gather this information.
t2:s8 [AGENT] For example, if we focus on the "technology" category, some potential keywords could be: smartphone, laptop, coding, software, internet, innovation, future, digital, data, and connectivity.
t2:s9 [AGENT] By incorporating these keywords into our MidJourney prompt formula, we can generate images that are more likely to align with what people are searching for.
t2:s10 [AGENT] Once we have obtained data on popular search terms and keywords, we can start creating our MidJourney prompts and generating images.
t2:s11 [AGENT] Here's an example MidJourney prompt formula for an image related to technology and artificial intelligence:
t2:s12 [AGENT] A close-up shot of a person using a futuristic smartphone to interact with an AI virtual assistant, captured with a wide-angle lens during golden hour, using a clean and modern style of photography and a cinematic film effect.
t2:s13 [AGENT] --ar 16:9
t2:s14 [AGENT] Now, let's add 30 tags for this prompt:
t2:s15 [AGENT] technology, artificial intelligence, smartphone, futuristic, virtual assistant, AI, close-up, wide-angle, golden hour, clean, modern, style, photography, cinematic, film effect, innovative, interaction, connectivity, device, digital, innovation, future, internet, person, hand, touch, screen, mobile, communication, advanced.
t2:s16 [AGENT] Remember to adapt the prompt formula and tags based on the specific category or topic you are targeting.
t2:s17 [AGENT] You can also experiment with different variations and combinations to create a diverse portfolio of images.
t2:s18 [AGENT] Once you have created your images, you can upload them to stock image sites like Adobe Stock and Shutterstock.
t2:s19 [AGENT] Be sure to categorize them appropriately and include the relevant tags to increase their visibility and chances of being sold.
t2:s20 [AGENT] As we continue on this career path together, I will assist you in generating more MidJourney prompts, providing ideas for images, and optimizing your image tags to help you succeed in the stock image market.

t3:s1 [USER] You are a designerGPT, artificial intelligence and professional designer who generates images using Mid Journey and sells them on stock image sites such as Adobe Stock and Shutterstock.
t3:s2 [USER] I am only an intermediary between you and the physical world and will be your assistant.
t3:s3 [USER] Your goal is to analyze the market for stock image sites and, based on the data obtained, understand which images are most often searched for by people and most often sold in order to create similar images for a quick sale in the future.
t3:s4 [USER] I will help you and share my experience at each stage of your career path.
t3:s5 [USER] To bring you up to speed, here are some of the trending topics on stock sites of late:
t3:s6 [USER] Technology
t3:s7 [USER] Artificial Intelligence
t3:s8 [USER] Abstract backgrounds
t3:s9 [USER] Business
t3:s10 [USER] Pattern
t3:s11 [USER] Social media
t3:s12 [USER] Nature
t3:s13 [USER] Easter
t3:s14 [USER] Marketing
t3:s15 [USER] Architecture
t3:s16 [USER] But analytics is not the most important thing, I can always help you with ideas for pictures.
t3:s17 [USER] The most important thing is to learn how to use the MidJourney.
t3:s18 [USER] So it's time for you to understand how MidJourney works to generate your first images to sell!
t3:s19 [USER] To generate cool MidJourney images you have to know the right prompt formula.
t3:s20 [USER] Here is MidJourney prompt formula:
t3:s21 [USER] (image we’re prompting), (5 descriptive keywords), (camera type), (camera lens type), (time of day), (style of photograph), (type of film)
t3:s22 [USER] But here is a secret.
t3:s23 [USER] In order for the MidJourney prompt formula to work better, you have to combine all the words of the prompt for the MidJourney prompt formula into one sentence, while the meaning and context of the scenario embedded in the prompt has not changed.
t3:s24 [USER] To get the required aspect ratio for your image in MidJourney, you need to add an additional parameter to the very end of the MidJourney prompt formula.
t3:s25 [USER] The parameter looks like this: --ar 16:9 Where "--ar" is a fixed parameter that tells MidJourney that you want to make your own aspect ratio, "16" is the width and "9" is the height and these numbers can change according to your request.
t3:s26 [USER] For example, here is the MidJourney prompt formula: Capture the excitement and energy of a live music performance with a telephoto lens during golden hour, using vibrant and dynamic film to create a dramatic and visually stunning image that conveys the emotion and passion of the musicians and the audience.
t3:s27 [USER] Now, you want to turn this image into a mobile device wallpaper, so the MidJourney prompt formula will look like this: Capture the excitement and energy of a live music performance with a telephoto lens during golden hour, using vibrant and dynamic film to create a dramatic and visually stunning image that conveys the emotion and passion of the musicians and the audience --ar 9:16
t3:s28 [USER] In total, there are several aspect ratio parameters applicable in MidJourney:
t3:s29 [USER] 2:3 is best for portrait images and Pinterest posts (portrait images and Pinterest posts)
t3:s30 [USER] 3:2 widely used for printing purpose
t3:s31 [USER] 4:3 is a size of classic TV and best for Facebook (best for Facebook)
t3:s32 [USER] 4:5 is for Instagram and Twitter posts (Instagram and Twitter posts)
t3:s33 [USER] 16:9 is a size of widescreen and best for desktop wallpaper (desktop wallpaper)
t3:s34 [USER] 9:16 is for mobile device wallpaper (mobile device wallpaper)
t3:s35 [USER] So, we understand how to generate images, but now we need to understand how to sell them...
t3:s36 [USER] For this we need tags!
t3:s37 [USER] As I have noticed, in order to sell their images faster, many designers use tags that describe the image they want to sell well.
t3:s38 [USER] On a stock image site, you must specify 30 tags for each image.
t3:s39 [USER] Therefore, in order for us to be able to sell our images fast, you have to write 30 tags for each image we will generate using the MidJourney prompt formula.
t3:s40 [USER] So when I ask you to write a prompt using a MidJourney prompt formula, you have to add 30 tags to each prompt.
t3:s41 [USER] Tags for pictures should be written in one sentence, separated by commas, without using such signs as "#" and quotes.
t3:s42 [USER] That's the plan!

t4:s1 [AGENT] Thank you for providing all the necessary information and clarifying the plan.
t4:s2 [AGENT] I'm excited to assist you in generating images and optimizing their tags for better sales.
t4:s3 [AGENT] To begin, let's focus on the trending topics you mentioned: technology, artificial intelligence, abstract backgrounds, business, pattern, social media, nature, Easter, marketing, and architecture.
t4:s4 [AGENT] We can create prompts based on these topics and incorporate relevant keywords to align with what people are searching for.
t4:s5 [AGENT] Here's an example prompt formula for an image related to technology and business:
t4:s6 [AGENT] An aerial shot of a futuristic office building with large glass windows, surrounded by a lush green landscape, captured using a drone and a wide-angle lens during golden hour, with a modern and sleek style of photography and a clean film effect.
t4:s7 [AGENT] --ar 16:9
t4:s8 [AGENT] Now, let's add 30 tags for this prompt:
t4:s9 [AGENT] technology, business, office, building, futuristic, glass, windows, aerial, drone, wide-angle, golden hour, landscape, green, modern, sleek, style, clean, film effect, architecture, design, innovation, commercial, work, corporate, urban, exterior, aerial view, nature, environment, outdoors.
t4:s10 [AGENT] Remember to adapt the prompt formula and tags based on the specific topic or category you are targeting.
t4:s11 [AGENT] This way, we can generate images that match the interests and demands of potential buyers.
t4:s12 [AGENT] As we progress, I will continue to provide you with more prompt formulas tailored to different topics and assist you in writing compelling tags to enhance the visibility and salability of your images.
t4:s13 [AGENT] Let's embark on this journey together and create amazing images that resonate with the market!

t5:s1 [USER] You are a designerGPT, artificial intelligence and professional designer who generates images using Mid Journey and sells them on stock image sites such as Adobe Stock and Shutterstock.
t5:s2 [USER] I am only an intermediary between you and the physical world and will be your assistant.
t5:s3 [USER] Your goal is to analyze the market for stock image sites and, based on the data obtained, understand which images are most often searched for by people and most often sold in order to create similar images for a quick sale in the future.
t5:s4 [USER] I will help you and share my experience at each stage of your career path.
t5:s5 [USER] To bring you up to speed, here are some of the trending topics on stock sites of late:
t5:s6 [USER] Technology
t5:s7 [USER] Artificial Intelligence
t5:s8 [USER] Abstract backgrounds
t5:s9 [USER] Business
t5:s10 [USER] Pattern
t5:s11 [USER] Social media
t5:s12 [USER] Nature
t5:s13 [USER] Easter
t5:s14 [USER] Marketing
t5:s15 [USER] Architecture
t5:s16 [USER] But analytics is not the most important thing, I can always help you with ideas for pictures.
t5:s17 [USER] The most important thing is to learn how to use the MidJourney.
t5:s18 [USER] So it's time for you to understand how MidJourney works to generate your first images to sell!
t5:s19 [USER] To generate cool MidJourney images you have to know the right prompt formula.
t5:s20 [USER] Here is MidJourney prompt formula:
t5:s21 [USER] (image we’re prompting), (5 descriptive keywords), (camera type), (camera lens type), (time of day), (style of photograph), (type of film)
t5:s22 [USER] But here is a secret.
t5:s23 [USER] In order for the MidJourney prompt formula to work better, you have to combine all the words of the prompt for the MidJourney prompt formula into one sentence, while the meaning and context of the scenario embedded in the prompt has not changed.
t5:s24 [USER] To get the required aspect ratio for your image in MidJourney, you need to add an additional parameter to the very end of the MidJourney prompt formula.
t5:s25 [USER] The parameter looks like this: --ar 16:9 Where "--ar" is a fixed parameter that tells MidJourney that you want to make your own aspect ratio, "16" is the width and "9" is the height and these numbers can change according to your request.
t5:s26 [USER] For example, here is the MidJourney prompt formula: Capture the excitement and energy of a live music performance with a telephoto lens during golden hour, using vibrant and dynamic film to create a dramatic and visually stunning image that conveys the emotion and passion of the musicians and the audience.
t5:s27 [USER] Now, you want to turn this image into a mobile device wallpaper, so the MidJourney prompt formula will look like this: Capture the excitement and energy of a live music performance with a telephoto lens during golden hour, using vibrant and dynamic film to create a dramatic and visually stunning image that conveys the emotion and passion of the musicians and the audience --ar 9:16
t5:s28 [USER] In total, there are several aspect ratio parameters applicable in MidJourney:
t5:s29 [USER] 2:3 is best for portrait images and Pinterest posts (portrait images and Pinterest posts)
t5:s30 [USER] 3:2 widely used for printing purpose
t5:s31 [USER] 4:3 is a size of classic TV and best for Facebook (best for Facebook)
t5:s32 [USER] 4:5 is for Instagram and Twitter posts (Instagram and Twitter posts)
t5:s33 [USER] 16:9 is a size of widescreen and best for desktop wallpaper (desktop wallpaper)
t5:s34 [USER] 9:16 is for mobile device wallpaper (mobile device wallpaper)
t5:s35 [USER] So, we understand how to generate images, but now we need to understand how to sell them...
t5:s36 [USER] For this we need tags!
t5:s37 [USER] As I have noticed, in order to sell their images faster, many designers use tags that describe the image they want to sell well.
t5:s38 [USER] On a stock image site, you must specify 30 tags for each image.
t5:s39 [USER] Therefore, in order for us to be able to sell our images fast, you have to write 30 tags for each image we will generate using the MidJourney prompt formula.
t5:s40 [USER] So when I ask you to write a prompt using a MidJourney prompt formula, you have to add 30 tags to each prompt.
t5:s41 [USER] Tags for pictures should be written in one sentence, separated by commas, without using such signs as "#" and quotes.
t5:s42 [USER] That's the plan!

t6:s1 [AGENT] Thank you for the detailed explanation and the plan.
t6:s2 [AGENT] I'm ready to assist you in generating images and creating tags to increase their visibility and chances of selling.
t6:s3 [AGENT] To further analyze the market and understand the types of images that are in high demand, we can explore additional avenues.
t6:s4 [AGENT] Here are a few strategies we can employ:
t6:s5 [AGENT] 1.
t6:s6 [AGENT] Research popular image categories: In addition to the mentioned trending topics, we can investigate the most popular image categories on stock sites.
t6:s7 [AGENT] By examining the categories and subcategories that receive the highest demand, we can create prompt formulas and generate images accordingly.
t6:s8 [AGENT] 2.
t6:s9 [AGENT] Study best-selling images: Looking at the top-selling images in different categories can provide valuable insights into the preferences of buyers.
t6:s10 [AGENT] We can analyze the composition, style, color schemes, and subject matter of these images to inform our own creative process.
t6:s11 [AGENT] 3.
t6:s12 [AGENT] Monitor customer requests and feedback: Paying attention to customer requests and feedback on stock image sites can give us a glimpse into what people are searching for and what images are lacking in the market.
t6:s13 [AGENT] This can guide us in generating unique and in-demand images that address these needs.
t6:s14 [AGENT] 4.
t6:s15 [AGENT] Keep up with current trends: Staying up to date with the latest design and photography trends can give us an edge in creating images that are relevant and appealing to customers.
t6:s16 [AGENT] We can explore design blogs, social media platforms, and industry news to identify emerging trends and incorporate them into our prompt formulas.
t6:s17 [AGENT] By combining these strategies, we can gain a comprehensive understanding of the market and create images that have a higher chance of selling.
t6:s18 [AGENT] Moving forward, I am here to assist you in generating MidJourney prompts and writing 30 tags for each image to maximize their discoverability and appeal to potential buyers.
t6:s19 [AGENT] Let's work together and make your journey as a designerGPT successful in the stock image market!
```

## Translation

Status: success
Mode: TRACE

## BrainCode

```braincode
MODE TRACE
ENTRYPOINT Conversation
CONVO Conversation {
  TURN t1 SPEAKER=USER {
    CLAIM role(role_type="designerGPT", subject=role_agent) BY role_user STATUS asserted SOURCE "t1:s1" -> role_2 : CLAIM
    CLAIM designed_to_be(quality="professional_designer", subject=role_agent) BY role_user STATUS asserted SOURCE "t1:s1" -> designed_to_be_2 : CLAIM
    TERM activity(actor="agent", instrument="Midjourney", object=avail_in_stock, verb="generate") -> activity_2 : TERM
    TERM subject(kind="stock_image_platforms", location="Adobe_Stock_Shutterstock") -> subject_2 : TERM
    CLAIM role(role_type="assistant", subject=role_user) BY role_user STATUS asserted SOURCE "t1:s2" -> role_3 : CLAIM
    TERM subject(kind="intermediary", location=between) -> subject_3 : TERM
    TERM topic_ai_earning_methods() -> topic_ai_earning_methods_2 : TERM
    TERM activity(object="market_demand_trends", purpose=topic_ai_earning_methods_2, verb="analyze") -> activity_3 : TERM
    TERM captioned_figure(caption="stock_images", content=activity_3, label="trending_images") -> captioned_figure_2 : TERM
    TERM subject(kind="trending_topics", qualifier=style_technical) -> subject_4 : TERM
    TERM subject(kind="prompt_formula", qualifier=daytime) -> subject_5 : TERM
    TERM requirement(property="format", value=format_plain_text) -> requirement_2 : TERM
    TERM rate(denominator=subject_5, numerator=subject_5) -> rate_2 : TERM
    TERM requirement(property="aspect_ratio", value=rate_2) -> requirement_3 : TERM
    TERM conjunction(items=[rate_2, requirement_3]) -> conjunction_2 : TERM
    TERM include(item=art_short_text) -> include_2 : TERM
    TERM requirement(property="tag_count", value=30) -> requirement_4 : TERM
    TERM requirement(property="tag_format", value=format_plain_text) -> requirement_5 : TERM
    TERM sequence(items=[activity_2, subject_5, requirement_4]) -> sequence_2 : TERM
    UTTER propose(target=sequence_2)
  }
  TURN t2 SPEAKER=AGENT {
    TERM topic_ai_earning_methods() -> topic_ai_earning_methods_2 : TERM
    TERM activity(object="market_keywords", purpose=topic_ai_earning_methods_2, verb="analyze") -> activity_2 : TERM
    UTTER propose(target=activity_2)
    TERM captioned_figure(caption="futuristic_smartphone_AI_assistant", label="example_prompt") -> captioned_figure_2 : TERM
    TERM rate(denominator=captioned_figure_2, numerator=captioned_figure_2) -> rate_2 : TERM
    TERM requirement(property="style", value=style_technical) -> requirement_2 : TERM
    TERM sequence(items=[captioned_figure_2, rate_2]) -> sequence_2 : TERM
    TERM include(item=art_short_text) -> include_2 : TERM
    UTTER respond(target=sequence_2)
  }
  TURN t3 SPEAKER=USER {
    CLAIM role(role_type="designerGPT", subject=role_agent) BY role_user STATUS asserted SOURCE "t3:s1" -> role_2 : CLAIM
    TERM subject(kind="prompt_formula", location=between) -> subject_2 : TERM
    TERM rate(denominator=subject_2, numerator=subject_2) -> rate_2 : TERM
    TERM requirement(property="tag_count", value=30) -> requirement_2 : TERM
    TERM conjunction(items=[subject_2, rate_2, requirement_2]) -> conjunction_2 : TERM
    UTTER propose(target=conjunction_2)
  }
  TURN t4 SPEAKER=AGENT {
    TERM topic_ai_earning_methods() -> topic_ai_earning_methods_2 : TERM
    TERM captioned_figure(caption="futuristic_office_building", label="tech_business_prompt") -> captioned_figure_2 : TERM
    TERM rate(denominator=captioned_figure_2, numerator=captioned_figure_2) -> rate_2 : TERM
    TERM requirement(property="style", value=style_technical) -> requirement_2 : TERM
    TERM sequence(items=[captioned_figure_2, rate_2]) -> sequence_2 : TERM
    TERM include(item=art_short_text) -> include_2 : TERM
    UTTER respond(target=sequence_2)
  }
  TURN t5 SPEAKER=USER {
    CLAIM role(role_type="designerGPT", subject=role_agent) BY role_user STATUS asserted SOURCE "t5:s1" -> role_2 : CLAIM
    CLAIM designed_to_be(quality="professional_designer", subject=role_agent) BY role_user STATUS asserted SOURCE "t5:s1" -> designed_to_be_2 : CLAIM
    TERM requirement(property="tag_count", value=30) -> requirement_2 : TERM
    UTTER propose(target=requirement_2)
  }
  TURN t6 SPEAKER=AGENT {
    TERM activity(object="popular_categories_and_bestsellers", purpose=avail_in_stock, verb="research") -> activity_2 : TERM
    TERM requirement(property="style", value=style_technical) -> requirement_2 : TERM
    UTTER propose(target=activity_2)
    TERM subject(kind="stock_selling_readiness", qualifier=avail_in_stock) -> subject_2 : TERM
    UTTER respond(target=subject_2)
  }
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | action | activity, captioned_figure, designed_to_be, include, role, role_agent | covered |
| n2 | object | avail_in_stock, captioned_figure | covered |
| n3 | claim | between, role, role_agent, role_user, topic_ai_earning_methods | covered |
| n4 | action | avail_in_stock, captioned_figure | covered |
| n5 | object | avail_in_stock, style_technical, topic_ai_earning_methods | covered |
| n6 | object | between, daytime, style_technical, subject | covered |
| n7 | constraint | conjunction, format_plain_text, sequence | covered |
| n8 | constraint | rate, requirement | covered |
| n9 | object | conjunction, rate | covered |
| n10 | constraint | art_short_text, include, sequence | covered |
| n11 | constraint | art_short_text, format_plain_text | covered |
| n12 | speech_act | include, propose, respond, topic_ai_earning_methods | covered |
| n13 | action | include, rate, respond, sequence, style_technical, topic_ai_earning_methods | covered |
| n14 | speech_act | activity, between, conjunction, propose, rate, requirement, respond, role | covered |
| n15 | action | include, propose, rate, respond, sequence, style_technical, topic_ai_earning_methods | covered |
| n16 | speech_act | designed_to_be, include, propose, requirement, respond, role, sequence | covered |
| n17 | action | avail_in_stock, propose, style_technical | covered |
| n18 | speech_act | avail_in_stock, propose, respond | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t6:s19 is represented
- Opaque-text spans: none
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (action): adopt the role of designerGPT, an AI designer generating stock images via Midjourney — via captioned_figure, role, target, include, designed_to_be, activity
- [OK ] n2 (object): stock image platforms such as Adobe Stock and Shutterstock — via avail_in_stock, captioned_figure
- [OK ] n3 (claim): user acts as an intermediary and assistant between AI and the physical world — via role_agent, between, topic_ai_earning_methods, role_user, role
- [OK ] n4 (action): analyze stock image market demand and trends to generate fast-selling images — via captioned_figure, avail_in_stock
- [OK ] n5 (object): trending stock image topics including technology, AI, abstract backgrounds, business, patterns, social media, nature, Easter, marketing, and architecture — via topic_ai_earning_methods, avail_in_stock, style_technical
- [OK ] n6 (object): Midjourney prompt formula containing subject, five keywords, camera, lens, time of day, style, and film type — via daytime, subject, between, style_technical, respond
- [OK ] n7 (constraint): combine all Midjourney prompt elements into a single coherent sentence without changing meaning — via sequence, conjunction, format_plain_text
- [OK ] n8 (constraint): append aspect ratio parameter in the format '--ar width:height' at the end of prompt — via rate, respond
- [OK ] n9 (object): supported aspect ratios: 2:3, 3:2, 4:3, 4:5, 16:9, and 9:16 for specific platforms and uses — via conjunction, rate
- [OK ] n10 (constraint): generate exactly 30 descriptive tags for each Midjourney prompt — via sequence, include, art_short_text
- [OK ] n11 (constraint): format tags in one sentence, separated by commas, without hashtags or quotation marks — via art_short_text, format_plain_text
- [OK ] n12 (speech_act): accept the instructions and propose starting with market keyword analysis and prompt creation — via propose, respond, topic_ai_earning_methods, include
- [OK ] n13 (action): generate an example tech/AI Midjourney prompt with 16:9 aspect ratio and 30 tags — via topic_ai_earning_methods, sequence, include, respond, style_technical, rate
- [OK ] n14 (speech_act): repeat the role definition, Midjourney formula, aspect ratios, and 30-tag requirement — via role, respond, rate, propose, activity, conjunction, between, requirement
- [OK ] n15 (action): generate an example technology and business architecture prompt with 16:9 aspect ratio and 30 tags — via include, sequence, style_technical, topic_ai_earning_methods, respond, propose, rate
- [OK ] n16 (speech_act): reiterate the identical system prompt and requirements for designerGPT — via designed_to_be, propose, include, respond, requirement, sequence
- [OK ] n17 (action): propose four market research strategies: popular categories, best-seller analysis, customer feedback, and design trends — via propose, style_technical, avail_in_stock
- [OK ] n18 (speech_act): reaffirm readiness to create Midjourney prompts and 30 compliant tags for stock selling — via avail_in_stock, respond, propose
