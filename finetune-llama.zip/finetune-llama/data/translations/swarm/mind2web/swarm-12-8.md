# Translation 12-8 — success

- Translator ID: 12-8
- Batch: 12
- Dataset: mind2web
- Item ID: mind2web-949e33a5-ceaa-4a52-973d-99eb97d49897
- Glossary version: 19.0.0-draft.2-lexical-groups+g16 (sha 212cd1a48bfd)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T20:46:04Z
- Needs: 16 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Search for the newest home workout English courses within 1 hour with subtitles for weight loss for beginners.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] [combobox]  Search for anything -> TYPE: home workout
t2:s3 [AGENT] 2.
t2:s4 [AGENT] [div]  home workout -> CLICK
t2:s5 [AGENT] 3.
t2:s6 [AGENT] [svg]   -> CLICK
t2:s7 [AGENT] 4.
t2:s8 [AGENT] [button]  Video Duration -> CLICK
t2:s9 [AGENT] 5.
t2:s10 [AGENT] [svg]   -> CLICK
t2:s11 [AGENT] 6.
t2:s12 [AGENT] [button]  Subtitles -> CLICK
t2:s13 [AGENT] 7.
t2:s14 [AGENT] [svg]   -> CLICK
t2:s15 [AGENT] 8.
t2:s16 [AGENT] [button]  Topic -> CLICK
t2:s17 [AGENT] 9.
t2:s18 [AGENT] [svg]   -> CLICK
t2:s19 [AGENT] 10.
t2:s20 [AGENT] [button]  Level -> CLICK
t2:s21 [AGENT] 11.
t2:s22 [AGENT] [svg]   -> CLICK
t2:s23 [AGENT] 12.
t2:s24 [AGENT] [combobox]  Sort by -> SELECT: Newest
```

## Translation

Status: success
Mode: TRACE

## BrainCode

```braincode
MODE TRACE
ENTRYPOINT Conversation
CONVO Conversation {
  TURN t1 SPEAKER=USER {
    TERM subject(kind="home_workout") -> subject_2 : TERM
    TERM subject(kind="weight_loss") -> subject_3 : TERM
    TERM training_program(audience="beginners", topic=subject_2) -> training_program_2 : TERM
    TERM duration(amount=1, unit=unit_hour) -> duration_2 : TERM
    TERM at_most(measure=duration_2) -> at_most_2 : TERM
    TERM requirement(property="duration", value=at_most_2) -> requirement_2 : TERM
    TERM requirement(property="language", value=locale_en_us) -> requirement_3 : TERM
    TERM requirement(property="topic", value=subject_3) -> requirement_4 : TERM
    TERM requirement(property="rank_direction", value=dir_desc) -> requirement_5 : TERM
    TERM include(item="subtitles") -> include_2 : TERM
    TERM constraint_beginner() -> constraint_beginner_2 : TERM
    CLAIM request(target=training_program_2) BY user STATUS asserted SOURCE "t1:s1" -> request_2 : CLAIM
  }
  TURN t2 SPEAKER=AGENT {
    TERM web_element(label="Search for anything", tag="combobox") -> web_element_2 : TERM
    RECORD ACTION type_text(target=web_element_2, text="home workout") STATUS succeeded SOURCE "t2:s2" -> type_text_event : EVENT
    TERM web_element(label="home workout", tag="div") -> web_element_3 : TERM
    RECORD ACTION click(target=web_element_3) STATUS succeeded SOURCE "t2:s4" -> click_event : EVENT
    TERM web_element(label="", tag="svg") -> web_element_4 : TERM
    RECORD ACTION click(target=web_element_4) STATUS succeeded SOURCE "t2:s6" -> click_event_2 : EVENT
    TERM web_element(label="Video Duration", tag="button") -> web_element_5 : TERM
    RECORD ACTION click(target=web_element_5) STATUS succeeded SOURCE "t2:s8" -> click_event_3 : EVENT
    TERM web_element(label="", tag="svg") -> web_element_6 : TERM
    RECORD ACTION click(target=web_element_6) STATUS succeeded SOURCE "t2:s10" -> click_event_4 : EVENT
    TERM web_element(label="Subtitles", tag="button") -> web_element_7 : TERM
    RECORD ACTION click(target=web_element_7) STATUS succeeded SOURCE "t2:s12" -> click_event_5 : EVENT
    TERM web_element(label="", tag="svg") -> web_element_8 : TERM
    RECORD ACTION click(target=web_element_8) STATUS succeeded SOURCE "t2:s14" -> click_event_6 : EVENT
    TERM web_element(label="Topic", tag="button") -> web_element_9 : TERM
    RECORD ACTION click(target=web_element_9) STATUS succeeded SOURCE "t2:s16" -> click_event_7 : EVENT
    TERM web_element(label="", tag="svg") -> web_element_10 : TERM
    RECORD ACTION click(target=web_element_10) STATUS succeeded SOURCE "t2:s18" -> click_event_8 : EVENT
    TERM web_element(label="Level", tag="button") -> web_element_11 : TERM
    RECORD ACTION click(target=web_element_11) STATUS succeeded SOURCE "t2:s20" -> click_event_9 : EVENT
    TERM web_element(label="", tag="svg") -> web_element_12 : TERM
    RECORD ACTION click(target=web_element_12) STATUS succeeded SOURCE "t2:s22" -> click_event_10 : EVENT
    TERM web_element(label="Sort by", tag="combobox") -> web_element_13 : TERM
    RECORD ACTION select_option(target=web_element_13, value="Newest") STATUS succeeded SOURCE "t2:s24" -> select_option_event : EVENT
  }
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | request | covered |
| n2 | action | training_program | covered |
| n3 | object | training_program, subject | covered |
| n4 | constraint | dir_desc, requirement | covered |
| n5 | constraint | locale_en_us, requirement | covered |
| n6 | temporal | duration, unit_hour, at_most, requirement | covered |
| n7 | constraint | include | covered |
| n8 | constraint | subject, requirement | covered |
| n9 | constraint | constraint_beginner | covered |
| n10 | action | type_text, web_element | covered |
| n11 | action | click, web_element | covered |
| n12 | action | click, web_element | covered |
| n13 | action | click, web_element | covered |
| n14 | action | click, web_element | covered |
| n15 | action | click, web_element | covered |
| n16 | action | select_option, web_element | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s24 is represented
- Opaque-text spans: none
- Label-preserved spans: none
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): User requests a search for specific online courses — via request, training_program
- [OK ] n2 (action): Search for courses — via training_program
- [OK ] n3 (object): Home workout courses — via unit_hour, training_program
- [OK ] n4 (constraint): Sort by newest courses — via dir_desc, rank_direction
- [OK ] n5 (constraint): Language must be English — via locale_en_us
- [OK ] n6 (temporal): Course duration within 1 hour — via unit_hour, duration, training_program
- [OK ] n7 (constraint): Must include subtitles — via include, constraint_beginner
- [OK ] n8 (constraint): Topic focused on weight loss — via constraint_beginner
- [OK ] n9 (constraint): Difficulty level for beginners — via constraint_beginner, requirement, training_program, at_most
- [OK ] n10 (action): Type 'home workout' into search input combobox — via type_text, training_program, click, web_element
- [OK ] n11 (action): Click 'home workout' suggestion — via click, select_option, training_program
- [OK ] n12 (action): Click Video Duration filter button — via click, duration
- [OK ] n13 (action): Click Subtitles filter button — via click
- [OK ] n14 (action): Click Topic filter button — via click, select_option, subject
- [OK ] n15 (action): Click Level filter button — via click, select_option
- [OK ] n16 (action): Select 'Newest' from the Sort by dropdown combobox — via select_option, rank_direction, click
