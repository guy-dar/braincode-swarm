# Translation 14-22 — success

- Translator ID: 14-22
- Batch: 14
- Dataset: mind2web
- Item ID: mind2web-c4166e68-7917-4d68-b091-e74dfaf23457
- Glossary version: 19.0.0-draft.2-lexical-groups+g19 (sha be5d8379f7a6)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T22:00:43Z
- Needs: 17 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Show me Mc Donald's reviews.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] [link]  Company reviews -> CLICK
t2:s3 [AGENT] 2.
t2:s4 [AGENT] [combobox]  Company name or job title -> TYPE: Mc Donald's
t2:s5 [AGENT] 3.
t2:s6 [AGENT] [button]  Find Companies -> CLICK
t2:s7 [AGENT] 4.
t2:s8 [AGENT] [link]  McDonald's reviews -> CLICK
```

## Translation

Status: success
Mode: TRACE

## BrainCode

```braincode
MODE TRACE
ENTRYPOINT Conversation
CONVO Conversation {
  TURN t1 SPEAKER=USER {
    TERM property_question(property="reviews", subject="Mc Donald's") -> property_question_2 : TERM
    UTTER ask(target=property_question_2)
  }
  TURN t2 SPEAKER=AGENT {
    TERM web_element(label="Company reviews", tag="link") -> web_element_2 : TERM
    RECORD ACTION click(target=web_element_2) STATUS succeeded SOURCE "t2:s2" -> click_event : EVENT
    TERM web_element(label="Company name or job title", tag="combobox") -> web_element_3 : TERM
    RECORD ACTION type_text(target=web_element_3, text="Mc Donald's") STATUS succeeded SOURCE "t2:s4" -> type_text_event : EVENT
    LINK then(next=type_text_event, previous=click_event) SOURCE "t2:s3"
    TERM web_element(label="Find Companies", tag="button") -> web_element_4 : TERM
    RECORD ACTION click(target=web_element_4) STATUS succeeded SOURCE "t2:s6" -> click_event_2 : EVENT
    LINK then(next=click_event_2, previous=type_text_event) SOURCE "t2:s5"
    TERM web_element(label="McDonald's reviews", tag="link") -> web_element_5 : TERM
    RECORD ACTION click(target=web_element_5) STATUS succeeded SOURCE "t2:s8" -> click_event_3 : EVENT
    LINK then(next=click_event_3, previous=click_event_2) SOURCE "t2:s7"
  }
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | ask | covered |
| n2 | action | ask, property_question | covered |
| n3 | object | property_question | covered |
| n4 | object | property_question | covered |
| n5 | temporal | then | covered |
| n6 | action | click | covered |
| n7 | object | web_element | covered |
| n8 | temporal | then | covered |
| n9 | action | type_text | covered |
| n10 | object | web_element | covered |
| n11 | object | type_text | covered |
| n12 | temporal | then | covered |
| n13 | action | click | covered |
| n14 | object | web_element | covered |
| n15 | temporal | then | covered |
| n16 | action | click | covered |
| n17 | object | web_element | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s8 is represented
- Opaque-text spans: none
- Label-preserved spans: none
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): User asks to see reviews for McDonald's. — via ask
- [DECL] n2 (action): Show or display reviews.
- [DECL] n3 (object): McDonald's company.
- [DECL] n4 (object): Customer or employee reviews.
- [OK ] n5 (temporal): First step in the sequence. — via then
- [OK ] n6 (action): Click on the link. — via click, web_element, then
- [DECL] n7 (object): Company reviews link element.
- [OK ] n8 (temporal): Second step in the sequence. — via then
- [OK ] n9 (action): Type text into an input field or combobox. — via type_text, web_element
- [DECL] n10 (object): Company name or job title combobox element.
- [DECL] n11 (object): Search query text 'Mc Donald's'.
- [OK ] n12 (temporal): Third step in the sequence. — via then
- [OK ] n13 (action): Click on the button. — via click, web_element
- [OK ] n14 (object): Find Companies button element. — via web_element
- [OK ] n15 (temporal): Fourth step in the sequence. — via then
- [OK ] n16 (action): Click on the link. — via click, web_element, then
- [DECL] n17 (object): McDonald's reviews link element.
