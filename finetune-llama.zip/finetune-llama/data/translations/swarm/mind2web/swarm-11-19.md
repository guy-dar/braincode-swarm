# Translation 11-19 — success

- Translator ID: 11-19
- Batch: 11
- Dataset: mind2web
- Item ID: mind2web-d361b836-2f91-4a0b-a602-8ec65a31c17e
- Glossary version: 19.0.0-draft.2-lexical-groups+g15 (sha d6391191e501)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T20:17:27Z
- Needs: 14 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Track order number 123456 for US.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] [link]  United States - English -> CLICK
t2:s3 [AGENT] 2.
t2:s4 [AGENT] [textbox]  Tracking Number -> TYPE: 123456
t2:s5 [AGENT] 3.
t2:s6 [AGENT] [button]  Track  -> CLICK
```

## Translation

Status: success
Mode: TRACE

## BrainCode

```braincode
MODE TRACE
ENTRYPOINT Conversation
CONVO Conversation {
  TURN t1 SPEAKER=USER {
    TERM subject(kind="order", qualifier="123456") -> subject_2 : TERM
    TERM activity(location=country::US, object=subject_2, verb="track") -> activity_2 : TERM
    CLAIM request(target=activity_2) BY role_user STATUS asserted SOURCE "t1:s1" -> request_2 : CLAIM
  }
  TURN t2 SPEAKER=AGENT {
    TERM web_element(label="United States - English", tag="link") -> web_element_2 : TERM
    RECORD ACTION click(target=web_element_2) STATUS succeeded SOURCE "t2:s2" -> click_event : EVENT
    TERM web_element(label="Tracking Number", tag="textbox") -> web_element_3 : TERM
    LINK then(next=type_text_event, previous=click_event) SOURCE "t2:s3"
    RECORD ACTION type_text(target=web_element_3, text="123456") STATUS succeeded SOURCE "t2:s4" -> type_text_event : EVENT
    TERM web_element(label="Track", tag="button") -> web_element_4 : TERM
    LINK then(next=click_event_2, previous=type_text_event) SOURCE "t2:s5"
    RECORD ACTION click(target=web_element_4) STATUS succeeded SOURCE "t2:s6" -> click_event_2 : EVENT
  }
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | request | covered |
| n2 | action | activity, request | covered |
| n3 | object | subject | covered |
| n4 | object | country::US, activity | covered |
| n5 | temporal | then | covered |
| n6 | action | click, web_element | covered |
| n7 | object | web_element | covered |
| n8 | temporal | then | covered |
| n9 | action | type_text, web_element | covered |
| n10 | object | web_element, type_text | covered |
| n11 | object | type_text | covered |
| n12 | temporal | then | covered |
| n13 | action | click, web_element | covered |
| n14 | object | web_element, click | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s6 is represented
- Opaque-text spans: none
- Label-preserved spans: none
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): request to track an order — via request
- [OK ] n2 (action): track an order or shipment — via request
- [DECL] n3 (object): order identifier number 123456
- [OK ] n4 (object): United States — via country
- [OK ] n5 (temporal): first step in procedure — via then
- [OK ] n6 (action): click a link element — via click, web_element, type_text, request
- [OK ] n7 (object): link labeled United States - English — via country
- [OK ] n8 (temporal): second step in procedure — via then
- [OK ] n9 (action): type text into an input field — via type_text, web_element
- [OK ] n10 (object): textbox labeled Tracking Number — via type_text
- [OK ] n11 (object): input string value 123456 — via type_text
- [OK ] n12 (temporal): third step in procedure — via then
- [OK ] n13 (action): click a button element — via click, web_element, type_text, request
- [OK ] n14 (object): button labeled Track — via click, request, web_element
