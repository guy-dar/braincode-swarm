# Translation 14-23 — success

- Translator ID: 14-23
- Batch: 14
- Dataset: mind2web
- Item ID: mind2web-af6655c8-0047-4c93-8da2-aeb04ff06b17
- Glossary version: 19.0.0-draft.2-lexical-groups+g19 (sha be5d8379f7a6)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T22:02:12Z
- Needs: 17 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Browse climbing courses within 50 miles of 90028.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] [link]  Classes & Events -> CLICK
t2:s3 [AGENT] 2.
t2:s4 [AGENT] [combobox]  Activity -> SELECT: Climbing
t2:s5 [AGENT] 3.
t2:s6 [AGENT] [textbox]  Location -> TYPE: 90028
t2:s7 [AGENT] 4.
t2:s8 [AGENT] [combobox]  Distance -> SELECT: Within 50 miles
t2:s9 [AGENT] 5.
t2:s10 [AGENT] [button]  Search -> CLICK
```

## Translation

Status: success
Mode: TRACE

## BrainCode

```braincode
MODE TRACE
ENTRYPOINT Conversation
CONVO Conversation {
  TURN t1 SPEAKER=USER {
    TERM location_spec(address="90028") -> location_spec_2 : TERM
    TERM requirement(property="distance", value="Within 50 miles") -> requirement_2 : TERM
    TERM training_program(audience="general", topic="climbing") -> training_program_2 : TERM
    CLAIM request(target=training_program_2) BY user STATUS asserted SOURCE "t1:s1" -> request_2 : CLAIM
  }
  TURN t2 SPEAKER=AGENT {
    TERM web_element(label="Classes & Events", tag="link") -> web_element_2 : TERM
    RECORD ACTION click(target=web_element_2) STATUS succeeded SOURCE "t2:s2" -> click_event : EVENT
    TERM web_element(label="Activity", tag="combobox") -> web_element_3 : TERM
    RECORD ACTION select_option(target=web_element_3, value="Climbing") STATUS succeeded SOURCE "t2:s4" -> select_option_event : EVENT
    TERM web_element(label="Location", tag="textbox") -> web_element_4 : TERM
    RECORD ACTION type_text(target=web_element_4, text="90028") STATUS succeeded SOURCE "t2:s6" -> type_text_event : EVENT
    TERM web_element(label="Distance", tag="combobox") -> web_element_5 : TERM
    RECORD ACTION select_option(target=web_element_5, value="Within 50 miles") STATUS succeeded SOURCE "t2:s8" -> select_option_2_event : EVENT
    TERM web_element(label="Search", tag="button") -> web_element_6 : TERM
    RECORD ACTION click(target=web_element_6) STATUS succeeded SOURCE "t2:s10" -> click_2_event : EVENT
  }
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | request | covered |
| n2 | action | request, training_program | covered |
| n3 | object | training_program | covered |
| n4 | constraint | location_spec, requirement | covered |
| n5 | action | click | covered |
| n6 | object | web_element | covered |
| n7 | action | select_option | covered |
| n8 | object | web_element | covered |
| n9 | constraint | select_option | covered |
| n10 | action | type_text | covered |
| n11 | object | web_element | covered |
| n12 | constraint | type_text | covered |
| n13 | action | select_option | covered |
| n14 | object | web_element | covered |
| n15 | constraint | select_option | covered |
| n16 | action | click | covered |
| n17 | object | web_element | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s10 is represented
- Opaque-text spans: none
- Label-preserved spans: none
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): User requests to search or browse climbing courses near a specific zip code and radius — via request, location_spec
- [OK ] n2 (action): Browse or search for courses — via training_program
- [OK ] n3 (object): Climbing courses — via training_program
- [OK ] n4 (constraint): Within 50 miles of zip code 90028 — via location_spec
- [OK ] n5 (action): Click on a link — via click, select_option, web_element, request
- [DECL] n6 (object): Classes & Events link
- [OK ] n7 (action): Select an option from a dropdown combobox — via select_option, click
- [OK ] n8 (object): Activity combobox — via click
- [OK ] n9 (constraint): Selected activity option is Climbing — via select_option, click
- [OK ] n10 (action): Type text into a textbox — via type_text, web_element
- [OK ] n11 (object): Location textbox — via location_spec, type_text
- [OK ] n12 (constraint): Entered location value is 90028 — via location_spec
- [OK ] n13 (action): Select an option from a dropdown combobox — via select_option, click
- [OK ] n14 (object): Distance combobox — via location_spec
- [OK ] n15 (constraint): Selected distance option is Within 50 miles — via location_spec, select_option
- [OK ] n16 (action): Click on a button — via click, request, select_option, web_element
- [OK ] n17 (object): Search button — via click, request, select_option
