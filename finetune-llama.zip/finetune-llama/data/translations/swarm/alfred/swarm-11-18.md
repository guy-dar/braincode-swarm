# Translation 11-18 — success

- Translator ID: 11-18
- Batch: 11
- Dataset: alfred
- Item ID: alfred-trial_T20190907_200550_857444#1
- Glossary version: 19.0.0-draft.2-lexical-groups+g15 (sha d6391191e501)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T20:22:21Z
- Needs: 50 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Put two CDs on the shelf.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Turn around, and go forward to the dresser.
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Pick up the CD from the dresser, in front of the leftmost clock.
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Turn left, move forward, then turn right to face the shelves.
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Put the CD on the second shelf down, to the right of the mug.
t2:s9 [AGENT] 5.
t2:s10 [AGENT] Right, move forward, then turn left to face the dresser.
t2:s11 [AGENT] 6.
t2:s12 [AGENT] Pick up the CD from the dresser, in front of the rightmost clock.
t2:s13 [AGENT] 7.
t2:s14 [AGENT] Turn left, move forward, then turn right to face the shelves.
t2:s15 [AGENT] 8.
t2:s16 [AGENT] Put the CD on the shelf, to the right of the other CD.
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT Conversation
CONVO Conversation {
  TURN t1 SPEAKER=USER {
    ACTION pick_up(target=object_label::cd, quantity=2) -> cd_refs : LIST[REF[STRING]]
    FOR EACH item IN cd_refs {
      ACTION place(target=item, destination=object_label::shelf, relation=on)
    }
  }
  TURN t2 SPEAKER=AGENT {
    ACTION turn(direction="around")
    ACTION walk(destination=object_label::dresser)
    ACTION pick_up(target=object_label::cd, source=object_label::dresser) -> cd_ref : REF[STRING]
    ACTION turn(direction="left")
    ACTION walk(destination=object_label::shelf)
    ACTION turn(direction="right")
    ACTION face(target=object_label::shelf)
    ACTION place(target=cd_ref, destination=object_label::shelf, location=object_label::mug, relation=right_of)
    ACTION turn(direction="right")
    ACTION walk(destination=object_label::dresser)
    ACTION turn(direction="left")
    ACTION face(target=object_label::dresser)
    ACTION pick_up(target=object_label::cd, source=object_label::dresser) -> cd_ref_2 : REF[STRING]
    ACTION turn(direction="left")
    ACTION walk(destination=object_label::shelf)
    ACTION turn(direction="right")
    ACTION face(target=object_label::shelf)
    ACTION place(target=cd_ref_2, destination=object_label::shelf, location=object_label::cd, relation=right_of)
  }
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | place | covered |
| n2 | action | place | covered |
| n3 | object | object_label::cd | label-preserved |
| n4 | constraint | quantity | covered |
| n5 | object | object_label::shelf | label-preserved |
| n6 | temporal | turn | covered |
| n7 | action | turn | covered |
| n8 | action | walk | covered |
| n9 | object | object_label::dresser | label-preserved |
| n10 | temporal | pick_up | covered |
| n11 | action | pick_up | covered |
| n12 | object | object_label::cd | label-preserved |
| n13 | object | object_label::dresser | label-preserved |
| n14 | object | — | not-applicable |
| n15 | constraint | — | not-applicable |
| n16 | temporal | turn | covered |
| n17 | action | turn | covered |
| n18 | action | walk | covered |
| n19 | action | turn | covered |
| n20 | object | object_label::shelf | label-preserved |
| n21 | constraint | face | covered |
| n22 | temporal | place | covered |
| n23 | action | place | covered |
| n24 | object | object_label::cd | label-preserved |
| n25 | object | object_label::shelf | label-preserved |
| n26 | object | object_label::mug | label-preserved |
| n27 | constraint | right_of | covered |
| n28 | temporal | turn | covered |
| n29 | action | turn | covered |
| n30 | action | walk | covered |
| n31 | action | turn | covered |
| n32 | object | object_label::dresser | label-preserved |
| n33 | constraint | face | covered |
| n34 | temporal | pick_up | covered |
| n35 | action | pick_up | covered |
| n36 | object | object_label::cd | label-preserved |
| n37 | object | object_label::dresser | label-preserved |
| n38 | object | — | not-applicable |
| n39 | constraint | — | not-applicable |
| n40 | temporal | turn | covered |
| n41 | action | turn | covered |
| n42 | action | walk | covered |
| n43 | action | turn | covered |
| n44 | object | object_label::shelf | label-preserved |
| n45 | constraint | face | covered |
| n46 | temporal | place | covered |
| n47 | action | place | covered |
| n48 | object | object_label::cd | label-preserved |
| n49 | object | object_label::shelf | label-preserved |
| n50 | constraint | right_of | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s16 is represented
- Opaque-text spans: none
- Label-preserved spans: t1:s1 "CDs" → object_label::cd, t1:s1 "shelf" → object_label::shelf, t2:s2 "dresser" → object_label::dresser, t2:s4 "CD" → object_label::cd, t2:s4 "dresser" → object_label::dresser, t2:s6 "shelves" → object_label::shelf, t2:s8 "CD" → object_label::cd, t2:s8 "shelf" → object_label::shelf, t2:s8 "mug" → object_label::mug, t2:s10 "dresser" → object_label::dresser, t2:s12 "CD" → object_label::cd, t2:s12 "dresser" -> object_label::dresser, t2:s14 "shelves" → object_label::shelf, t2:s16 "CD" → object_label::cd, t2:s16 "shelf" → object_label::shelf
- Missing constructs: none
- Unresolved ambiguities: none
- Not-applicable justifications: n14, n15, n38, n39 (leftmost/rightmost clock landmarks) are spatial sub-specifiers for the target CD on the dresser; the pick_up operation acquires the CD using target (object_label::cd) and source (object_label::dresser) directly as defined in the operation profile.
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): instruct to place items — via place
- [OK ] n2 (action): put or place — via place, on, right_of, walk
- [OK ] n3 (object): CD — via cd, object_label
- [OK ] n4 (constraint): quantity of two — via quantity
- [OK ] n5 (object): shelf — via shelf, cd, dresser, object_label
- [DECL] n6 (temporal): step 1
- [OK ] n7 (action): turn around — via turn
- [OK ] n8 (action): go forward — via walk
- [OK ] n9 (object): dresser — via dresser, shelf, object_label
- [OK ] n10 (temporal): step 2 — via on
- [OK ] n11 (action): pick up — via pick_up
- [OK ] n12 (object): CD — via cd, object_label
- [OK ] n13 (object): dresser — via dresser, shelf, object_label
- [LABEL] n14 (object): leftmost clock — via object_label
- [OK ] n15 (constraint): in front of the leftmost clock — via dresser
- [DECL] n16 (temporal): step 3
- [OK ] n17 (action): turn left — via turn, walk, right_of
- [OK ] n18 (action): move forward — via walk, turn, face
- [OK ] n19 (action): turn right — via turn, right_of, on
- [OK ] n20 (object): shelves — via shelf, dresser, object_label
- [OK ] n21 (constraint): face the shelves — via shelf, dresser, face
- [DECL] n22 (temporal): step 4
- [OK ] n23 (action): put or place — via place, walk, on, right_of
- [OK ] n24 (object): CD — via cd, object_label
- [OK ] n25 (object): second shelf down — via shelf, dresser, on, object_label
- [OK ] n26 (object): mug — via mug, object_label
- [OK ] n27 (constraint): to the right of the mug — via mug, right_of, dresser, on
- [DECL] n28 (temporal): step 5
- [OK ] n29 (action): turn right — via turn, right_of, on
- [OK ] n30 (action): move forward — via walk, turn, face
- [OK ] n31 (action): turn left — via turn, walk, right_of
- [OK ] n32 (object): dresser — via dresser, shelf, object_label
- [OK ] n33 (constraint): face the dresser — via dresser, face
- [DECL] n34 (temporal): step 6
- [OK ] n35 (action): pick up — via pick_up
- [OK ] n36 (object): CD — via cd, object_label
- [OK ] n37 (object): dresser — via dresser, shelf, object_label
- [LABEL] n38 (object): rightmost clock — via object_label
- [DECL] n39 (constraint): in front of the rightmost clock
- [DECL] n40 (temporal): step 7
- [OK ] n41 (action): turn left — via turn, walk, right_of
- [OK ] n42 (action): move forward — via walk, turn, face
- [OK ] n43 (action): turn right — via turn, right_of, on
- [OK ] n44 (object): shelves — via shelf, dresser, object_label
- [OK ] n45 (constraint): face the shelves — via shelf, dresser, face
- [DECL] n46 (temporal): step 8
- [OK ] n47 (action): put or place — via place, walk, on, right_of
- [OK ] n48 (object): CD — via cd, object_label
- [OK ] n49 (object): shelf — via shelf, dresser, cd, object_label
- [OK ] n50 (constraint): to the right of the other CD — via right_of, cd

Needs covered by an open-group label only (report as label-preserved): n14; n38
