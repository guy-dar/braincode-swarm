# Translation 14-18 — success

- Translator ID: 14-18
- Batch: 14
- Dataset: alfred
- Item ID: alfred-trial_T20190907_052853_431363#0
- Glossary version: 19.0.0-draft.2-lexical-groups+g19 (sha be5d8379f7a6)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T21:59:48Z
- Needs: 19 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Turn a lamp on with a basketball in hand.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Look down at the end of the white table with the computer on it.
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Pick the basketball up from under the table.
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Go left towards the desk with the lamp on it.
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Turn the lamp on.
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT Basketball
TASK Basketball {
  ACTION look(direction="down")
  ACTION pick_up(target=object_label::basketball, source=object_label::table) -> basketball_ref : REF[STRING]
  ACTION turn(direction="left")
  ACTION walk(destination=object_label::desk)
  ACTION turn_on(target=object_label::lamp)
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | turn_on | covered |
| n2 | action | turn_on | covered |
| n3 | object | object_label::lamp | label-preserved |
| n4 | object | object_label::basketball | label-preserved |
| n5 | constraint | pick_up | covered |
| n6 | action | look | covered |
| n7 | object | object_label::table | label-preserved |
| n8 | constraint | — | not-applicable |
| n9 | object | — | not-applicable |
| n10 | constraint | — | not-applicable |
| n11 | action | pick_up | covered |
| n12 | object | object_label::basketball | label-preserved |
| n13 | constraint | object_label::table | covered |
| n14 | action | walk, turn | covered |
| n15 | object | object_label::desk | label-preserved |
| n16 | object | object_label::lamp | label-preserved |
| n17 | constraint | object_label::desk | covered |
| n18 | action | turn_on | covered |
| n19 | object | object_label::lamp | label-preserved |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s8 is represented
- Opaque-text spans: none
- Label-preserved spans: t1:s1 "lamp" -> object_label::lamp; t1:s1 "basketball" -> object_label::basketball; t2:s2 "table" -> object_label::table; t2:s4 "basketball" -> object_label::basketball; t2:s6 "desk" -> object_label::desk; t2:s6 "lamp" -> object_label::lamp; t2:s8 "lamp" -> object_label::lamp
- Missing constructs: none
- Unresolved ambiguities: none
- Justifications: n8 ("white"), n9 ("computer"), and n10 ("at the end of the table with the computer on it") are descriptive landmark qualifiers for the gaze direction in t2:s2 ("Look down at the end of the white table with the computer on it"); the operational action is look(direction="down") and the table reference is captured in pick_up(source=object_label::table).
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): instruct to turn on a lamp while holding a basketball — via lamp, turn_on, turn
- [OK ] n2 (action): turn on — via turn_on, turn, look
- [OK ] n3 (object): lamp — via lamp, object_label
- [LABEL] n4 (object): basketball — via object_label
- [DECL] n5 (constraint): holding basketball in hand
- [OK ] n6 (action): look down — via look, turn
- [OK ] n7 (object): table — via table, desk, lamp, object_label
- [OK ] n8 (constraint): white — via desk
- [OK ] n9 (object): computer — via desk, lamp, object_label
- [OK ] n10 (constraint): at the end of the table with the computer on it — via table, desk, lamp
- [OK ] n11 (action): pick up — via pick_up, look
- [LABEL] n12 (object): basketball — via object_label
- [OK ] n13 (constraint): from under the table — via table, desk
- [OK ] n14 (action): go left — via walk, turn
- [OK ] n15 (object): desk — via desk, lamp, table, object_label
- [OK ] n16 (object): lamp — via lamp, object_label
- [OK ] n17 (constraint): towards the desk with the lamp on it — via lamp, desk, table
- [OK ] n18 (action): turn on — via turn_on, turn, look
- [OK ] n19 (object): lamp — via lamp, object_label

Needs covered by an open-group label only (report as label-preserved): n4; n12
