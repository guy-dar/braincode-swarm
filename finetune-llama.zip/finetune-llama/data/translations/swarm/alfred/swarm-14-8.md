# Translation 14-8 — success

- Translator ID: 14-8
- Batch: 14
- Dataset: alfred
- Item ID: alfred-trial_T20190909_055242_347953#0
- Glossary version: 19.0.0-draft.2-lexical-groups+g19 (sha be5d8379f7a6)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T21:54:50Z
- Needs: 21 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Take the pen out of the waste basket and put it in the bedside table.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Turn left, walk slightly forward, turn left, walk to the wall, turn left so you are facing the waste basket.
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Pick up the red pen in the waste basket.
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Turn left, take a step, turn left, walk to the table beside the bed.
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Put the pen on the end table behind the CD.
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT TrashCan
TASK TrashCan {
  ACTION turn(direction="left")
  ACTION walk()
  ACTION turn(direction="left")
  ACTION walk(destination=wall)
  ACTION turn(direction="left")
  ACTION face(target=trash_can)
  ACTION pick_up(target=pen, color=color_label::red, source=trash_can) -> pen_ref : REF[STRING]
  ACTION turn(direction="left")
  ACTION walk()
  ACTION turn(direction="left")
  ACTION walk(destination=night_stand)
  ACTION place(target=pen_ref, destination=table, location=cd, relation=behind)
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | Task TrashCan | covered |
| n2 | action | pick_up | covered |
| n3 | object | pen | covered |
| n4 | object | trash_can | covered |
| n5 | action | place | covered |
| n6 | object | night_stand | covered |
| n7 | action | turn | covered |
| n8 | action | walk | covered |
| n9 | action | walk, wall | covered |
| n10 | object | wall | covered |
| n11 | constraint | face, trash_can | covered |
| n12 | action | pick_up | covered |
| n13 | constraint | color_label::red | label-preserved |
| n14 | object | pen, color_label::red | covered |
| n15 | action | turn, walk | covered |
| n16 | action | walk, night_stand | covered |
| n17 | object | night_stand | covered |
| n18 | action | place | covered |
| n19 | object | table | covered |
| n20 | constraint | behind, cd | covered |
| n21 | object | cd | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s8 is represented
- Opaque-text spans: none
- Label-preserved spans: t2:s4 "red" → color_label::red (label only; no sense resolved)
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): Instruct to move an item from a waste basket to a bedside table — via night_stand, table, trash_can
- [OK ] n2 (action): Take out or remove — via pick_up
- [OK ] n3 (object): pen — via pen
- [OK ] n4 (object): waste basket — via trash_can
- [OK ] n5 (action): Put or place inside or on — via place
- [OK ] n6 (object): bedside table — via night_stand, table, wall
- [OK ] n7 (action): Turn left — via turn, walk
- [OK ] n8 (action): Walk slightly forward — via walk, wall, turn, behind
- [OK ] n9 (action): Walk to the wall — via wall, walk
- [OK ] n10 (object): wall — via wall
- [OK ] n11 (constraint): Face the waste basket — via trash_can, face
- [OK ] n12 (action): Pick up or take — via pick_up
- [LABEL] n13 (constraint): red — via color_label
- [OK ] n14 (object): red pen — via pen
- [OK ] n15 (action): Turn left and take a step — via turn, pick_up, walk
- [OK ] n16 (action): Walk to the table beside the bed — via table, walk, night_stand, wall
- [OK ] n17 (object): bed — via night_stand, wall
- [OK ] n18 (action): Put or place — via place, walk, behind
- [OK ] n19 (object): end table — via table, night_stand, wall
- [OK ] n20 (constraint): Position behind the CD — via behind, cd, wall
- [OK ] n21 (object): CD — via cd

Needs covered by an open-group label only (report as label-preserved): n13
