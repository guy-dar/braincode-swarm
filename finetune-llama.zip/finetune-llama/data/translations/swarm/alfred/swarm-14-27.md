# Translation 14-27 — success

- Translator ID: 14-27
- Batch: 14
- Dataset: alfred
- Item ID: alfred-trial_T20190908_001113_685684#0
- Glossary version: 19.0.0-draft.2-lexical-groups+g19 (sha be5d8379f7a6)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T22:05:58Z
- Needs: 26 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Place a washed kettle on a stove.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Turn around and walk past the fridge to the corner of the cabinets.
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Open the cabinet to the left of the corner and pick up the kettle.
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Take a step left to the sink.
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Wash the kettle in the sink.
t2:s9 [AGENT] 5.
t2:s10 [AGENT] Turn left and walk along the counter to the stove.
t2:s11 [AGENT] 6.
t2:s12 [AGENT] Place the kettle on the front right burner.
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT Cabinet
TASK Cabinet {
  ACTION turn(direction="turn_around")
  ACTION walk(destination=fridge)
  ACTION walk(destination=corner)
  ACTION open(target=cabinet)
  ACTION pick_up(target=object_label::kettle, source=cabinet) -> kettle_ref : REF[STRING]
  ACTION walk(destination=sink)
  ACTION rinse(target=kettle_ref, destination=sink) -> kettle_ref_2 : REF[STRING]
  ACTION turn(direction="left")
  ACTION walk(destination=counter)
  ACTION walk(destination=stove)
  ACTION place(target=kettle_ref_2, destination=stove, relation=on)
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | TASK Cabinet | covered |
| n2 | action | place | covered |
| n3 | object | object_label::kettle | label-preserved |
| n4 | constraint | rinse | covered |
| n5 | object | stove | covered |
| n6 | action | turn | covered |
| n7 | action | walk | covered |
| n8 | object | fridge | covered |
| n9 | object | corner | covered |
| n10 | action | open | covered |
| n11 | object | cabinet | covered |
| n12 | action | pick_up | covered |
| n13 | object | object_label::kettle | label-preserved |
| n14 | action | walk | covered |
| n15 | object | sink | covered |
| n16 | action | rinse | covered |
| n17 | object | object_label::kettle | label-preserved |
| n18 | object | sink | covered |
| n19 | action | turn | covered |
| n20 | action | walk | covered |
| n21 | object | counter | covered |
| n22 | object | stove | covered |
| n23 | action | place | covered |
| n24 | object | object_label::kettle | label-preserved |
| n25 | object | stove | covered |
| n26 | constraint | on | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s12 is represented
- Opaque-text spans: none
- Label-preserved spans: t1:s1, t2:s4, t2:s8, t2:s12 "kettle" → object_label::kettle (label only; no sense resolved)
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): request to place a washed kettle on a stove — via stove, counter, sink, fridge, rinse, place
- [OK ] n2 (action): place an object on a surface — via place, counter, rinse
- [OK ] n3 (object): kettle — via stove, sink, object_label
- [OK ] n4 (constraint): kettle must be washed — via rinse, sink
- [OK ] n5 (object): stove — via stove, counter, sink, object_label
- [OK ] n6 (action): turn around — via turn, corner
- [OK ] n7 (action): walk past the fridge to the corner of the cabinets — via fridge, cabinet, walk, corner, counter, stove
- [OK ] n8 (object): refrigerator — via fridge, cabinet, counter, object_label
- [OK ] n9 (object): cabinet corner — via cabinet, corner, counter, stove, object_label
- [OK ] n10 (action): open the cabinet to the left of the corner — via cabinet, open, corner, counter, stove, fridge, turn
- [OK ] n11 (object): cabinet — via cabinet, counter, fridge, stove, object_label
- [OK ] n12 (action): pick up the kettle — via pick_up, stove, fridge
- [OK ] n13 (object): kettle — via stove, sink, object_label
- [OK ] n14 (action): step to the left towards the sink — via sink, counter, fridge, turn, walk
- [OK ] n15 (object): sink — via sink, counter, rinse, object_label
- [OK ] n16 (action): wash the kettle in the sink — via sink, rinse, counter
- [OK ] n17 (object): kettle — via stove, sink, object_label
- [OK ] n18 (object): sink — via sink, counter, rinse, object_label
- [OK ] n19 (action): turn left — via turn, corner, walk
- [OK ] n20 (action): walk along the counter to the stove — via counter, stove, walk, cabinet, fridge, sink
- [OK ] n21 (object): countertop — via counter, cabinet, stove, sink, object_label
- [OK ] n22 (object): stove — via stove, counter, sink, object_label
- [OK ] n23 (action): place the kettle on the front right burner — via place, stove, fridge, counter, turn
- [OK ] n24 (object): kettle — via stove, sink, object_label
- [OK ] n25 (object): stove burner — via stove, counter, fridge, object_label
- [OK ] n26 (constraint): front right burner position — via stove, on
