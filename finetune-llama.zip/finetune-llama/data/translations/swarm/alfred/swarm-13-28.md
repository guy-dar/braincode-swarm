# Translation 13-28 — success

- Translator ID: 13-28
- Batch: 13
- Dataset: alfred
- Item ID: alfred-trial_T20190908_103604_088470#1
- Glossary version: 19.0.0-draft.2-lexical-groups+g17 (sha 018146c57ffa)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T21:31:38Z
- Needs: 32 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Place pencils in a drawer

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Walk to the bed then turn left and cross the room, turn left to face the side of the white desk
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Pick up the leftmost pencil that is sitting on the white desk
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Turn left and walk to the end of the bed, then turn right and face the drawers that are built into the wall
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Open the bottom right hand drawer and place the pencil inside and shut the drawer
t2:s9 [AGENT] 5.
t2:s10 [AGENT] Head across the room to the built in drawers then turn right to face the white desk
t2:s11 [AGENT] 6.
t2:s12 [AGENT] Pick up the yellow pencil sitting on the desk
t2:s13 [AGENT] 7.
t2:s14 [AGENT] Turn around and take a step forward then turn left and and walk past the desk chair, turn around to face the drawers built into the wall
t2:s15 [AGENT] 8.
t2:s16 [AGENT] Open the bottom right drawer and place the pencil inside then close the drawer
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT Conversation
CONVO Conversation {
  TURN t1 SPEAKER=USER {
    TERM activity(object=object_label::pencil, verb="place") -> activity_2 : TERM
    UTTER ask(target=activity_2)
  }
  TURN t2 SPEAKER=AGENT {
    ACTION walk(destination=object_label::bed)
    ACTION turn(direction="left")
    ACTION walk(destination=object_label::room)
    ACTION turn(direction="left")
    ACTION face(target=object_label::desk)
    ACTION pick_up(target=object_label::pencil, color=color_label::white, source=object_label::desk) -> pencil_ref : REF[STRING]
    ACTION turn(direction="left")
    ACTION walk(destination=object_label::bed)
    ACTION turn(direction="right")
    ACTION face(target=object_label::drawer)
    ACTION open(target=object_label::drawer)
    ACTION place(target=pencil_ref, destination=object_label::drawer, relation=in)
    ACTION close(target=object_label::drawer)
    ACTION walk(destination=object_label::drawer)
    ACTION turn(direction="right")
    ACTION face(target=object_label::desk)
    ACTION pick_up(target=object_label::pencil, color=color_label::yellow, source=object_label::desk) -> pencil_ref_2 : REF[STRING]
    ACTION turn(direction="around")
    ACTION walk(destination=object_label::forward)
    ACTION turn(direction="left")
    ACTION walk(destination=object_label::chair)
    ACTION turn(direction="around")
    ACTION face(target=object_label::drawer)
    ACTION open(target=object_label::drawer)
    ACTION place(target=pencil_ref_2, destination=object_label::drawer, relation=in)
    ACTION close(target=object_label::drawer)
  }
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | ask | covered |
| n2 | action | activity | covered |
| n3 | object | object_label::pencil | label-preserved |
| n4 | object | object_label::drawer | label-preserved |
| n5 | action | walk | covered |
| n6 | object | object_label::bed | label-preserved |
| n7 | action | turn, walk | covered |
| n8 | action | turn, face | covered |
| n9 | object | object_label::desk | label-preserved |
| n10 | constraint | color_label::white | label-preserved |
| n11 | action | pick_up | covered |
| n12 | object | object_label::pencil | label-preserved |
| n13 | constraint | object_label::desk | label-preserved |
| n14 | action | turn, walk | covered |
| n15 | action | turn, face | covered |
| n16 | object | object_label::drawer | label-preserved |
| n17 | action | open | covered |
| n18 | constraint | object_label::drawer | label-preserved |
| n19 | action | place, in | covered |
| n20 | action | close | covered |
| n21 | action | walk | covered |
| n22 | action | turn, face | covered |
| n23 | action | pick_up | covered |
| n24 | object | object_label::pencil | label-preserved |
| n25 | constraint | color_label::yellow | label-preserved |
| n26 | action | turn, walk | covered |
| n27 | action | turn, walk | covered |
| n28 | object | object_label::chair | label-preserved |
| n29 | action | turn, face | covered |
| n30 | action | open | covered |
| n31 | action | place, in | covered |
| n32 | action | close | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s16 is represented
- Opaque-text spans: none
- Label-preserved spans: t1:s1 "pencil" → object_label::pencil; t1:s1 "drawer" → object_label::drawer; t2:s2 "bed" → object_label::bed; t2:s2 "desk" → object_label::desk; t2:s2 "white" → color_label::white; t2:s6 "drawers" → object_label::drawer; t2:s12 "pencil" → object_label::pencil; t2:s12 "yellow" → color_label::yellow; t2:s14 "desk chair" → object_label::chair
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): request to place pencils in a drawer — via pencil, ask, place
- [OK ] n2 (action): place object into container — via place, open
- [OK ] n3 (object): pencils — via pencil, object_label
- [OK ] n4 (object): drawer — via pencil, object_label
- [OK ] n5 (action): walk to the bed — via bed, walk, desk
- [OK ] n6 (object): bed — via bed, desk, object_label, chair
- [OK ] n7 (action): turn left and cross the room — via turn, desk, bed
- [OK ] n8 (action): turn left to face the side of the white desk — via desk, turn, face, chair
- [OK ] n9 (object): desk — via desk, pencil, chair, object_label
- [OK ] n10 (constraint): white — via color_label, desk
- [OK ] n11 (action): pick up the pencil — via pencil, pick_up
- [OK ] n12 (object): pencil — via pencil, chair, object_label
- [OK ] n13 (constraint): leftmost on the desk — via desk, chair
- [OK ] n14 (action): turn left and walk to the end of the bed — via bed, turn, walk, desk, activity
- [OK ] n15 (action): turn right and face the wall-integrated drawers — via turn, face, desk, close
- [OK ] n16 (object): built-in drawers — via desk, object_label
- [OK ] n17 (action): open the drawer — via open, pencil, close
- [OK ] n18 (constraint): bottom right hand drawer — via pencil
- [OK ] n19 (action): place the pencil inside the drawer — via pencil, place, in, desk
- [OK ] n20 (action): shut the drawer — via close
- [OK ] n21 (action): head across the room towards the built-in drawers — via desk, walk, bed
- [OK ] n22 (action): turn right to face the white desk — via desk, turn, face
- [OK ] n23 (action): pick up the yellow pencil from the desk — via pencil, desk, pick_up
- [OK ] n24 (object): pencil — via pencil, chair, object_label
- [LABEL] n25 (constraint): yellow — via color_label
- [OK ] n26 (action): turn around and step forward — via turn, walk
- [OK ] n27 (action): turn left and walk past the desk chair — via desk, turn, chair, walk
- [OK ] n28 (object): desk chair — via desk, chair, pencil, object_label
- [OK ] n29 (action): turn around to face the wall-built drawers — via turn, face, desk, close
- [OK ] n30 (action): open the bottom right drawer — via open, turn, close, chair
- [OK ] n31 (action): place the pencil inside the drawer — via pencil, place, in, desk
- [OK ] n32 (action): close the drawer — via close

Needs covered by an open-group label only (report as label-preserved): n25
