# Translation 12-16 — success

- Translator ID: 12-16
- Batch: 12
- Dataset: alfred
- Item ID: alfred-trial_T20190909_065706_103190#1
- Glossary version: 19.0.0-draft.2-lexical-groups+g16 (sha 212cd1a48bfd)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T20:48:55Z
- Needs: 46 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Put two statues on the table.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Go right, turn left, go across the room, turn right toward the black shelves on the wall.
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Pick up the green statue on the top shelf.
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Turn right and go across the room to the black table.
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Put the green statue on the table.
t2:s9 [AGENT] 5.
t2:s10 [AGENT] Turn around and go back to the shelves on the wall.
t2:s11 [AGENT] 6.
t2:s12 [AGENT] Pick up the white statue from the bottom shelf.
t2:s13 [AGENT] 7.
t2:s14 [AGENT] Turn right and go across the room to the black table in the corner.
t2:s15 [AGENT] 8.
t2:s16 [AGENT] Put the white statue on the table to the left of the green statue.
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT Figurine
TASK Figurine {
  ACTION turn(direction="right")
  ACTION turn(direction="left")
  ACTION walk(destination=shelf)
  ACTION turn(direction="right")
  ACTION pick_up(target=figurine, color=color_label::green, source=shelf) -> figurine_ref : REF[STRING]
  ACTION turn(direction="right")
  ACTION walk(destination=table)
  ACTION place(target=figurine_ref, destination=table)
  ACTION turn(direction="around")
  ACTION walk(destination=shelf)
  ACTION pick_up(target=figurine, color=color_label::white, source=shelf) -> figurine_ref_2 : REF[STRING]
  ACTION turn(direction="right")
  ACTION walk(destination=table)
  ACTION place(target=figurine_ref_2, destination=table, location=corner, relation=left_of)
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | place, figurine, table | covered |
| n2 | action | place | covered |
| n3 | object | figurine | covered |
| n4 | constraint | figurine_ref, figurine_ref_2 | covered |
| n5 | object | table | covered |
| n6 | temporal | turn, walk | covered |
| n7 | action | turn | covered |
| n8 | action | turn, walk, shelf | covered |
| n9 | object | shelf | covered |
| n10 | constraint | shelf | covered |
| n11 | object | shelf | covered |
| n12 | temporal | pick_up | covered |
| n13 | action | pick_up | covered |
| n14 | object | figurine | covered |
| n15 | constraint | color_label::green | label-preserved |
| n16 | constraint | shelf | covered |
| n17 | temporal | turn, walk | covered |
| n18 | action | turn, walk, table | covered |
| n19 | object | table | covered |
| n20 | constraint | table | covered |
| n21 | temporal | place | covered |
| n22 | action | place | covered |
| n23 | object | figurine | covered |
| n24 | constraint | color_label::green | label-preserved |
| n25 | object | table | covered |
| n26 | temporal | turn, walk | covered |
| n27 | action | turn, walk, shelf | covered |
| n28 | object | shelf | covered |
| n29 | temporal | pick_up | covered |
| n30 | action | pick_up | covered |
| n31 | object | figurine | covered |
| n32 | constraint | color_label::white | label-preserved |
| n33 | constraint | shelf | covered |
| n34 | temporal | turn, walk | covered |
| n35 | action | turn, walk, table | covered |
| n36 | object | table | covered |
| n37 | constraint | table | covered |
| n38 | constraint | corner | covered |
| n39 | temporal | place | covered |
| n40 | action | place | covered |
| n41 | object | figurine | covered |
| n42 | constraint | color_label::white | label-preserved |
| n43 | object | table | covered |
| n44 | constraint | left_of, figurine | covered |
| n45 | object | figurine | covered |
| n46 | constraint | color_label::green | label-preserved |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s16 is represented
- Opaque-text spans: none
- Label-preserved spans: t2:s4 "green" → color_label::green; t2:s8 "green" → color_label::green; t2:s12 "white" → color_label::white; t2:s16 "white" → color_label::white; t2:s16 "green" → color_label::green
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): command or instruct to place statues on a table — via figurine, table, place
- [OK ] n2 (action): place or put — via place, walk
- [OK ] n3 (object): statue — via figurine
- [DECL] n4 (constraint): quantity of two
- [OK ] n5 (object): table — via table, shelf
- [OK ] n6 (temporal): step 1 — via left_of
- [OK ] n7 (action): go right and turn left — via turn, walk, left_of, corner
- [OK ] n8 (action): go across the room and turn right toward shelves — via turn, shelf, walk, table
- [OK ] n9 (object): shelves — via shelf, table
- [OK ] n10 (constraint): black — via color_label, left_of
- [OK ] n11 (object): wall — via shelf, corner
- [OK ] n12 (temporal): step 2 — via left_of
- [OK ] n13 (action): pick up an object — via pick_up, place
- [OK ] n14 (object): statue — via figurine
- [OK ] n15 (constraint): green — via color_label, left_of
- [OK ] n16 (constraint): located on the top shelf — via shelf, table
- [OK ] n17 (temporal): step 3 — via left_of
- [OK ] n18 (action): turn right and go across the room to the table — via table, turn, walk
- [OK ] n19 (object): table — via table, shelf
- [OK ] n20 (constraint): black — via color_label, left_of
- [OK ] n21 (temporal): step 4 — via table, left_of
- [OK ] n22 (action): put green statue on the table — via figurine, table, place
- [OK ] n23 (object): statue — via figurine
- [OK ] n24 (constraint): green — via color_label, left_of
- [OK ] n25 (object): table — via table, shelf
- [OK ] n26 (temporal): step 5 — via left_of, table
- [OK ] n27 (action): turn around and return to the shelves on the wall — via shelf, turn
- [OK ] n28 (object): shelves — via shelf, table
- [OK ] n29 (temporal): step 6 — via left_of
- [OK ] n30 (action): pick up an object — via pick_up, place
- [OK ] n31 (object): statue — via figurine
- [LABEL] n32 (constraint): white — via color_label
- [OK ] n33 (constraint): located on the bottom shelf — via shelf, table
- [OK ] n34 (temporal): step 7 — via left_of, walk
- [OK ] n35 (action): turn right and go across the room to the table — via table, turn, walk
- [OK ] n36 (object): table — via table, shelf
- [OK ] n37 (constraint): black — via color_label, left_of
- [OK ] n38 (constraint): located in the corner — via corner, left_of
- [OK ] n39 (temporal): step 8 — via left_of
- [OK ] n40 (action): put statue on the table — via figurine, table, place
- [OK ] n41 (object): statue — via figurine
- [LABEL] n42 (constraint): white — via color_label
- [OK ] n43 (object): table — via table, shelf
- [OK ] n44 (constraint): placed to the left of the green statue — via left_of, figurine
- [OK ] n45 (object): statue — via figurine
- [OK ] n46 (constraint): green — via color_label, left_of

Needs covered by an open-group label only (report as label-preserved): n32; n42
