# Translation 12-30 — success

- Translator ID: 12-30
- Batch: 12
- Dataset: alfred
- Item ID: alfred-trial_T20190908_070716_813332#1
- Glossary version: 19.0.0-draft.2-lexical-groups+g16 (sha 212cd1a48bfd)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T21:02:10Z
- Needs: 20 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Put a heated tomato in the sink.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Turn right to face the counter.
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Pick up the leftmost tomato off of the counter.
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Turn left and walk forward, then hang a left and walk up to the microwave.
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Microwave the tomato for a couple seconds, then take it out of the microwave and close the door.
t2:s9 [AGENT] 5.
t2:s10 [AGENT] Turn left and walk over to the sink.
t2:s11 [AGENT] 6.
t2:s12 [AGENT] Put the heated tomato in the sink basin.
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT Counter
TASK Counter {
  ACTION turn(direction="right")
  ACTION face(target=counter)
  ACTION pick_up(target=food_label::tomato, source=counter) -> food_label_tomato_ref : REF[STRING]
  ACTION turn(direction="left")
  ACTION turn(direction="left")
  ACTION walk(destination=microwave)
  ACTION heat(target=food_label_tomato_ref, destination=microwave) -> food_label_tomato_ref_2 : REF[STRING]
  ACTION wait(duration=2)
  ACTION remove(target=food_label_tomato_ref_2, source=microwave)
  ACTION close(target=microwave)
  ACTION turn(direction="left")
  ACTION walk(destination=sink)
  ACTION place(target=food_label_tomato_ref_2, destination=sink)
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | place | covered |
| n2 | action | place | covered |
| n3 | object | food_label::tomato | label-preserved |
| n4 | constraint | heat | covered |
| n5 | object | sink | covered |
| n6 | action | face, turn | covered |
| n7 | object | counter | covered |
| n8 | action | pick_up | covered |
| n9 | object | food_label::tomato | label-preserved |
| n10 | constraint | pick_up | not-applicable |
| n11 | action | turn, walk | covered |
| n12 | action | turn, walk | covered |
| n13 | object | microwave | covered |
| n14 | action | heat | covered |
| n15 | temporal | wait | covered |
| n16 | action | remove | covered |
| n17 | action | close | covered |
| n18 | action | turn, walk | covered |
| n19 | action | place | covered |
| n20 | object | sink | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s12 is represented
- Opaque-text spans: none
- Label-preserved spans: t1:s1 "tomato" -> food_label::tomato; t2:s4 "tomato" -> food_label::tomato (open group food_label; denotes labeled food kind without resolved semantic sense)
- Missing constructs: none
- Unresolved ambiguities: none; n10 ("leftmost") is marked not-applicable because the pick_up operation acquires the target from the counter source and does not provide a superlative spatial ranking parameter
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): request to put a heated tomato into the sink — via sink, counter, heat, place
- [OK ] n2 (action): place an item — via place
- [LABEL] n3 (object): tomato — via food_label
- [OK ] n4 (constraint): heated or warm state — via heat
- [OK ] n5 (object): sink — via sink, counter
- [OK ] n6 (action): turn right to face counter — via counter, turn, face
- [OK ] n7 (object): counter — via counter, sink
- [OK ] n8 (action): pick up item — via pick_up, remove
- [LABEL] n9 (object): leftmost tomato — via food_label
- [DECL] n10 (constraint): leftmost position
- [OK ] n11 (action): turn left and walk forward — via turn, walk
- [OK ] n12 (action): turn left and walk to microwave — via microwave, turn, walk, counter
- [OK ] n13 (object): microwave — via microwave, counter
- [OK ] n14 (action): microwave or heat tomato — via microwave, heat
- [OK ] n15 (temporal): duration of a couple of seconds — via duration, wait
- [OK ] n16 (action): take tomato out of microwave — via microwave, remove, pick_up, wait
- [OK ] n17 (action): close microwave door — via microwave, close, wait, counter
- [OK ] n18 (action): turn left and walk to sink — via sink, turn, walk, counter
- [OK ] n19 (action): put heated tomato into sink basin — via sink, heat, place, counter
- [OK ] n20 (object): sink basin — via sink, counter

Needs covered by an open-group label only (report as label-preserved): n3; n9
