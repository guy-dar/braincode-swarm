# Translation 12-28 — success

- Translator ID: 12-28
- Batch: 12
- Dataset: alfred
- Item ID: alfred-trial_T20190909_012724_686117#2
- Glossary version: 19.0.0-draft.2-lexical-groups+g16 (sha 212cd1a48bfd)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T20:58:55Z
- Needs: 27 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Put a smartphone next to a laptop on the bed.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Make a left and move to the window seat.
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Pick up the smartphone above the blue pencil.
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Turn left and walk to the bed.
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Set the smartphone down next to the laptop closest to the stuffed animal.
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT ObjectLabelPhone
TASK ObjectLabelPhone {
  ACTION turn(direction="left")
  ACTION walk(destination=object_label::chair)
  ACTION pick_up(target=object_label::phone, color=color_label::blue, source=object_label::pencil) -> object_label_phone_ref : REF[STRING]
  ACTION turn(direction="left")
  ACTION walk(destination=object_label::bed)
  ACTION place(target=object_label_phone_ref, destination=object_label::bed, location=object_label::laptop, relation=next_to)
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | place | covered |
| n2 | action | place | covered |
| n3 | object | object_label::phone | label-preserved |
| n4 | object | object_label::laptop | label-preserved |
| n5 | object | object_label::bed | label-preserved |
| n6 | constraint | next_to | covered |
| n7 | constraint | destination=object_label::bed | covered |
| n8 | temporal | turn, walk | covered |
| n9 | action | turn | covered |
| n10 | action | walk | covered |
| n11 | object | object_label::chair | label-preserved |
| n12 | temporal | pick_up | covered |
| n13 | action | pick_up | covered |
| n14 | object | object_label::phone | label-preserved |
| n15 | constraint | source=object_label::pencil | covered |
| n16 | constraint | color_label::blue | label-preserved |
| n17 | object | object_label::pencil | label-preserved |
| n18 | temporal | turn, walk | covered |
| n19 | action | turn | covered |
| n20 | action | walk | covered |
| n21 | object | object_label::bed | label-preserved |
| n22 | temporal | place | covered |
| n23 | action | place | covered |
| n24 | object | object_label::phone | label-preserved |
| n25 | constraint | next_to | covered |
| n26 | object | object_label::laptop | label-preserved |
| n27 | object | object_label::chair | label-preserved |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s8 is represented
- Opaque-text spans: none
- Label-preserved spans: t1:s1 "smartphone" → object_label::phone, "laptop" → object_label::laptop, "bed" → object_label::bed; t2:s2 "window seat" → object_label::chair; t2:s4 "phone" → object_label::phone, "pencil" → object_label::pencil, "blue" → color_label::blue; t2:s6 "bed" → object_label::bed; t2:s8 "phone" → object_label::phone, "laptop" → object_label::laptop
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): Instruct to place a smartphone next to a laptop on a bed — via phone, laptop, bed, next_to, place
- [OK ] n2 (action): Place an object — via place, walk
- [OK ] n3 (object): smartphone — via phone, laptop, chair, object_label
- [OK ] n4 (object): laptop — via laptop, phone, object_label
- [OK ] n5 (object): bed — via bed, object_label, chair
- [OK ] n6 (constraint): Located next to the laptop — via laptop, bed, chair, next_to
- [OK ] n7 (constraint): Located on the bed — via bed, chair
- [OK ] n8 (temporal): Step 1 of navigation plan — via walk, turn
- [OK ] n9 (action): Turn left — via turn, walk
- [OK ] n10 (action): Move to the window seat — via chair, walk
- [OK ] n11 (object): window seat — via chair, laptop, object_label
- [OK ] n12 (temporal): Step 2 of navigation plan — via walk, turn
- [OK ] n13 (action): Pick up an object — via pick_up, place
- [OK ] n14 (object): smartphone — via phone, laptop, chair, turn, object_label
- [OK ] n15 (constraint): Located above the blue pencil — via pencil
- [LABEL] n16 (constraint): blue — via color_label
- [OK ] n17 (object): pencil — via pencil, chair, object_label
- [OK ] n18 (temporal): Step 3 of navigation plan — via walk, turn
- [OK ] n19 (action): Turn left — via turn, walk
- [OK ] n20 (action): Walk to the bed — via bed, walk, next_to
- [OK ] n21 (object): bed — via bed, object_label, chair
- [OK ] n22 (temporal): Step 4 of navigation plan — via walk, turn
- [OK ] n23 (action): Set down the smartphone — via phone, turn, laptop
- [OK ] n24 (object): smartphone — via phone, laptop, chair, turn, object_label
- [OK ] n25 (constraint): Next to the laptop closest to the stuffed animal — via laptop, next_to
- [OK ] n26 (object): laptop — via laptop, phone, chair, object_label
- [OK ] n27 (object): stuffed animal — via chair, object_label

Needs covered by an open-group label only (report as label-preserved): n16
