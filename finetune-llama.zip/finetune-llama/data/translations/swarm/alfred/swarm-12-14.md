# Translation 12-14 — success

- Translator ID: 12-14
- Batch: 12
- Dataset: alfred
- Item ID: alfred-trial_T20190907_000225_007699#0
- Glossary version: 19.0.0-draft.2-lexical-groups+g16 (sha 212cd1a48bfd)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T20:49:09Z
- Needs: 25 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Use the remote on the white shelf to turn on the lamp to the left of the couch.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Move to the shelves on the left across the room.
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Pick up the remote control on top of the shelf.
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Head to the lamp on the right.
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Turn on the lamp with the remote.
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT Conversation
CONVO Conversation {
  TURN t1 SPEAKER=USER {
    TERM lexical_label(value=color_label::white) -> lexical_label_2 : TERM
    TERM subject(kind="shelf", qualifier=lexical_label_2) -> subject_2 : TERM
    TERM subject(kind="couch") -> subject_3 : TERM
    TERM lexical_label(value=object_label::lamp) -> lexical_label_3 : TERM
    TERM spatial_constraint(object=lexical_label_3, reference=subject_3, relation=left_of) -> spatial_constraint_2 : TERM
    TERM lexical_label(value=object_label::remote) -> lexical_label_4 : TERM
    TERM spatial_constraint(object=lexical_label_4, reference=subject_2, relation=on) -> spatial_constraint_3 : TERM
    TERM activity(instrument=remote_control, object=lamp, verb="turn_on") -> activity_2 : TERM
    UTTER propose(target=activity_2, constraints=[spatial_constraint_2, spatial_constraint_3])
  }
  TURN t2 SPEAKER=AGENT {
    TERM subject(kind="shelf") -> subject_4 : TERM
    TERM subject(kind="room") -> subject_5 : TERM
    TERM spatial_constraint(object=subject_4, reference=subject_5, relation=left_of) -> spatial_constraint_4 : TERM
    TERM activity(object=subject_4, verb="walk") -> activity_3 : TERM
    TERM subject(kind="remote_control") -> subject_6 : TERM
    TERM spatial_constraint(object=subject_6, reference=subject_4, relation=on) -> spatial_constraint_5 : TERM
    TERM activity(object=subject_6, verb="pick_up") -> activity_4 : TERM
    TERM subject(kind="lamp") -> subject_7 : TERM
    TERM spatial_constraint(object=subject_7, reference=subject_5, relation=right_of) -> spatial_constraint_6 : TERM
    TERM activity(object=subject_7, verb="walk") -> activity_5 : TERM
    TERM activity(instrument=remote_control, object=lamp, verb="turn_on") -> activity_6 : TERM
    TERM sequence(items=[activity_3, activity_4, activity_5, activity_6]) -> sequence_2 : TERM
    UTTER propose(target=sequence_2)
  }
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | propose, activity, remote_control, lamp | covered |
| n2 | action | turn_on, remote_control | covered |
| n3 | object | remote_control | covered |
| n4 | object | shelf | covered |
| n5 | constraint | color_label::white | label-preserved |
| n6 | action | turn_on | covered |
| n7 | object | lamp | covered |
| n8 | object | subject | covered |
| n9 | constraint | spatial_constraint, left_of | covered |
| n10 | temporal | sequence, propose | covered |
| n11 | action | activity, walk | covered |
| n12 | object | shelf | covered |
| n13 | constraint | spatial_constraint, left_of | covered |
| n14 | temporal | sequence, propose | covered |
| n15 | action | activity, pick_up | covered |
| n16 | object | remote_control | covered |
| n17 | constraint | spatial_constraint, on, shelf | covered |
| n18 | temporal | sequence, propose | covered |
| n19 | action | activity, walk | covered |
| n20 | object | lamp | covered |
| n21 | constraint | spatial_constraint, right_of | covered |
| n22 | temporal | sequence, propose | covered |
| n23 | action | turn_on, lamp | covered |
| n24 | object | lamp | covered |
| n25 | object | remote_control | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s8 is represented
- Opaque-text spans: none
- Label-preserved spans: t1:s1 "white" → color_label::white (label only; no color coordinates resolved); t1:s1 "couch" → subject(kind="couch")
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): User instructs agent to turn on a lamp using a remote on a white shelf — via lamp, remote_control, turn_on, propose, shelf
- [OK ] n2 (action): use a remote control to turn on a device — via remote_control, turn_on, on
- [OK ] n3 (object): remote control — via remote_control, turn_on, object_label
- [OK ] n4 (object): shelf — via shelf, object_label
- [OK ] n5 (constraint): white — via color_label, on
- [OK ] n6 (action): turn on — via turn_on, on, propose
- [OK ] n7 (object): lamp — via lamp, object_label
- [OK ] n8 (object): couch — via on, object_label
- [OK ] n9 (constraint): located to the left of the couch — via left_of, on
- [OK ] n10 (temporal): step 1 of a sequential plan — via sequence, propose
- [OK ] n11 (action): move across the room to the shelves — via shelf, walk
- [OK ] n12 (object): shelves — via shelf, object_label
- [OK ] n13 (constraint): on the left across the room — via left_of, on
- [OK ] n14 (temporal): step 2 of a sequential plan — via sequence, propose
- [OK ] n15 (action): pick up an object — via pick_up, propose
- [OK ] n16 (object): remote control — via remote_control, turn_on, object_label
- [OK ] n17 (constraint): on top of the shelf — via shelf, on
- [OK ] n18 (temporal): step 3 of a sequential plan — via sequence, propose
- [OK ] n19 (action): head to or navigate towards a target — via walk, turn_on, target, propose
- [OK ] n20 (object): lamp — via lamp, object_label
- [OK ] n21 (constraint): on the right — via right_of, on, left_of
- [OK ] n22 (temporal): step 4 of a sequential plan — via sequence, propose
- [OK ] n23 (action): turn on the lamp — via lamp, turn_on, on, propose
- [OK ] n24 (object): lamp — via lamp, object_label
- [OK ] n25 (object): remote control — via remote_control, turn_on, object_label
