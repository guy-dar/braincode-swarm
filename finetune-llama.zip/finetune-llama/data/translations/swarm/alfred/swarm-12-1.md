# Translation 12-1 — success

- Translator ID: 12-1
- Batch: 12
- Dataset: alfred
- Item ID: alfred-trial_T20190911_115046_843723#1
- Glossary version: 19.0.0-draft.2-lexical-groups+g16 (sha 212cd1a48bfd)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T20:38:32Z
- Needs: 33 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Place a pan containing a knife and tomato into a fridge

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Turn right, cross the room, then turn left to face the round white table
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Pick up the knife
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Continue to face the round white table
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Slice the tomato that is sitting on the table
t2:s9 [AGENT] 5.
t2:s10 [AGENT] Turn left and head to the trash can, then turn left and walk to the stove across the room to your left
t2:s11 [AGENT] 6.
t2:s12 [AGENT] Place the knife in the pan that is on the right back burner of the stove
t2:s13 [AGENT] 7.
t2:s14 [AGENT] Turn around and cross the room, once past the counter take a right and head to the wall, then turn left and face the round white table
t2:s15 [AGENT] 8.
t2:s16 [AGENT] Pick up a slice of the tomato
t2:s17 [AGENT] 9.
t2:s18 [AGENT] Turn to your left and head across the room, once past the first counter on your left, turn left and walk to the stove
t2:s19 [AGENT] 10.
t2:s20 [AGENT] Place the tomato in the pan that on the right back burner, the one that contains the knife
t2:s21 [AGENT] 11.
t2:s22 [AGENT] Pick up the pan that contains the knife and the tomato slice
t2:s23 [AGENT] 12.
t2:s24 [AGENT] Turn to your right and walk to the black fridge
t2:s25 [AGENT] 13.
t2:s26 [AGENT] Open the fridge and place the pan containing the knife and tomato inside on the slotted shelf then close the door
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT Table
TASK Table {
  ACTION turn(direction="right")
  ACTION walk(destination=table)
  ACTION turn(direction="left")
  ACTION face(target=table)
  ACTION pick_up(target=knife) -> knife_ref : REF[STRING]
  ACTION face(target=table)
  TERM lexical_label(value=food_label::tomato) -> lexical_label_2 : TERM
  ACTION slice(target=lexical_label_2) -> slice_ref : REF[STRING]
  ACTION turn(direction="left")
  ACTION walk(destination=trash_can)
  ACTION turn(direction="left")
  ACTION walk(destination=stove)
  ACTION place(target=knife_ref, destination=pan, location=stove, relation=in)
  ACTION turn(direction="around")
  ACTION walk(destination=counter)
  ACTION turn(direction="right")
  ACTION walk(destination=wall)
  ACTION turn(direction="left")
  ACTION face(target=table)
  ACTION pick_up(target=food_label::tomato, source=table, state=state_sliced) -> tomato_ref : REF[STRING]
  ACTION turn(direction="left")
  ACTION walk(destination=counter)
  ACTION turn(direction="left")
  ACTION walk(destination=stove)
  ACTION place(target=tomato_ref, destination=pan, location=stove, relation=in)
  ACTION pick_up(target=pan, source=stove) -> pan_ref : REF[STRING]
  ACTION turn(direction="right")
  ACTION walk(destination=fridge)
  TERM lexical_label(value=object_label::fridge) -> lexical_label_3 : TERM
  ACTION open(target=lexical_label_3)
  ACTION place(target=pan_ref, destination=shelf, location=fridge, relation=in)
  TERM lexical_label(value=object_label::door) -> lexical_label_4 : TERM
  ACTION close(target=lexical_label_4)
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | TASK Table | covered |
| n2 | action | place | covered |
| n3 | object | pan | covered |
| n4 | object | knife | covered |
| n5 | object | food_label::tomato | label-preserved |
| n6 | object | fridge | covered |
| n7 | action | turn, walk, face | covered |
| n8 | object | table | covered |
| n9 | constraint | table | covered |
| n10 | action | pick_up | covered |
| n11 | object | knife | covered |
| n12 | action | face | covered |
| n13 | action | slice | covered |
| n14 | object | food_label::tomato | label-preserved |
| n15 | action | turn, walk | covered |
| n16 | object | trash_can | covered |
| n17 | object | stove | covered |
| n18 | action | place | covered |
| n19 | object | pan | covered |
| n20 | action | turn, walk, face | covered |
| n21 | object | counter | covered |
| n22 | action | pick_up | covered |
| n23 | object | food_label::tomato, state_sliced | covered |
| n24 | action | turn, walk | covered |
| n25 | action | place | covered |
| n26 | action | pick_up | covered |
| n27 | action | turn, walk | covered |
| n28 | object | fridge | covered |
| n29 | constraint | fridge | covered |
| n30 | action | open | covered |
| n31 | action | place | covered |
| n32 | object | shelf | covered |
| n33 | action | close | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s26 is represented
- Opaque-text spans: none
- Label-preserved spans: t1:s1 "tomato" -> food_label::tomato (label only; food kind from open group); t2:s8 "tomato" -> food_label::tomato; t2:s16 "tomato" -> food_label::tomato; t2:s20 "tomato" -> food_label::tomato; t2:s26 "fridge" -> object_label::fridge; t2:s26 "door" -> object_label::door
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): instruct to place a pan containing a knife and tomato into a fridge — via knife, fridge, pan, counter, stove, place
- [OK ] n2 (action): place a pan containing items into a fridge — via fridge, pan, place, counter, stove
- [OK ] n3 (object): pan — via pan, object_label
- [OK ] n4 (object): knife — via knife, counter, state_sliced, object_label
- [LABEL] n5 (object): tomato — via food_label
- [OK ] n6 (object): fridge — via fridge, trash_can, shelf, object_label
- [OK ] n7 (action): turn right, cross the room, and turn left to face the round white table — via table, turn, counter, face, wall
- [OK ] n8 (object): round white table — via table, counter, wall, object_label
- [OK ] n9 (constraint): white — via wall
- [OK ] n10 (action): pick up the knife — via knife, pick_up, counter, slice, state_sliced
- [OK ] n11 (object): knife — via knife, counter, state_sliced, slice, object_label
- [OK ] n12 (action): continue to face the round white table — via table, face, counter, wall
- [OK ] n13 (action): slice the tomato sitting on the table — via slice, table, state_sliced, knife
- [LABEL] n14 (object): tomato — via food_label
- [OK ] n15 (action): turn left, walk to the trash can, turn left, and walk to the stove across the room — via stove, walk, trash_can, counter, turn, door, wall
- [OK ] n16 (object): trash can — via trash_can, object_label
- [OK ] n17 (object): stove — via stove, counter, wall, pan, object_label
- [OK ] n18 (action): place the knife into the pan on the right back burner of the stove — via stove, knife, pan, place, counter, turn
- [OK ] n19 (object): pan on right back burner — via pan, counter, stove, object_label
- [OK ] n20 (action): turn around, cross room, go past counter, turn right to wall, turn left to face round white table — via counter, turn, wall, table, face
- [OK ] n21 (object): counter — via counter, table, stove, knife, wall, object_label
- [OK ] n22 (action): pick up a slice of the tomato — via slice, state_sliced, pick_up, knife
- [OK ] n23 (object): tomato slice — via state_sliced, slice, knife, food_label
- [OK ] n24 (action): turn left, walk across room past counter, turn left, walk to stove — via counter, turn, stove, walk, door, wall
- [OK ] n25 (action): place tomato into pan containing knife on right back burner — via knife, pan, place, counter, stove, turn
- [OK ] n26 (action): pick up pan containing knife and tomato slice — via knife, slice, pan, state_sliced, pick_up, counter
- [OK ] n27 (action): turn right and walk to the black fridge — via fridge, turn, walk, counter, wall, door
- [OK ] n28 (object): black fridge — via fridge, counter, shelf, object_label
- [OK ] n29 (constraint): black — via wall
- [OK ] n30 (action): open the fridge — via fridge, open, door, counter, close
- [OK ] n31 (action): place pan containing knife and tomato onto slotted shelf inside fridge — via fridge, knife, pan, shelf, place, in, counter, stove
- [OK ] n32 (object): slotted shelf — via shelf, counter, table, wall, object_label
- [OK ] n33 (action): close the fridge door — via close, fridge, door, open, shelf

Needs covered by an open-group label only (report as label-preserved): n5; n14
