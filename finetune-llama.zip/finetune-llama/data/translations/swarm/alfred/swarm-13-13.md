# Translation 13-13 — success

- Translator ID: 13-13
- Batch: 13
- Dataset: alfred
- Item ID: alfred-trial_T20190907_120947_947901#0
- Glossary version: 19.0.0-draft.2-lexical-groups+g17 (sha 018146c57ffa)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T21:19:13Z
- Needs: 21 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Putting bread in a trash can

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Head to the left of the oven
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Grab the knife off of the counter
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Turn right and head to the counter to the right of the oven
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Slice the loaf of bread into slices
t2:s9 [AGENT] 5.
t2:s10 [AGENT] Place the knife on the counter
t2:s11 [AGENT] 6.
t2:s12 [AGENT] Grab a slice of bread
t2:s13 [AGENT] 7.
t2:s14 [AGENT] Turn around and head to the microwave
t2:s15 [AGENT] 8.
t2:s16 [AGENT] Put the bread in the microwave and cook it.
t2:s17 [AGENT] Grab the bread and close the microwave.
t2:s18 [AGENT] 9.
t2:s19 [AGENT] Turn left and stop at the trash can
t2:s20 [AGENT] 10.
t2:s21 [AGENT] Throw the bread in the trash can
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT Bread
TASK Bread {
  ACTION walk(destination=object_label::oven, relation=left_of)
  ACTION pick_up(target=knife, source=counter) -> knife_ref : REF[STRING]
  ACTION turn(direction="right")
  ACTION walk(destination=counter, relation=right_of)
  ACTION slice(target=bread) -> bread_ref : REF[STRING]
  ACTION place(target=knife_ref, destination=counter)
  ACTION pick_up(target=bread, state=state_sliced) -> bread_ref_2 : REF[STRING]
  ACTION turn(direction="around")
  ACTION walk(destination=microwave)
  ACTION place(target=bread_ref_2, destination=microwave)
  ACTION heat(target=bread_ref_2, destination=microwave) -> bread_ref_3 : REF[STRING]
  ACTION pick_up(target=bread, source=microwave) -> bread_ref_4 : REF[STRING]
  ACTION close(target=microwave)
  ACTION turn(direction="left")
  ACTION walk(destination=trash_can)
  ACTION place(target=bread_ref_4, destination=trash_can)
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | TASK | covered |
| n2 | action | place | covered |
| n3 | object | bread | covered |
| n4 | object | trash_can | covered |
| n5 | action | walk, left_of | covered |
| n6 | object | object_label::oven | label-preserved |
| n7 | action | pick_up | covered |
| n8 | object | knife | covered |
| n9 | object | counter | covered |
| n10 | action | turn, walk, right_of | covered |
| n11 | action | slice | covered |
| n12 | object | bread | covered |
| n13 | action | place | covered |
| n14 | action | pick_up, state_sliced | covered |
| n15 | object | bread | covered |
| n16 | action | turn, walk | covered |
| n17 | object | microwave | covered |
| n18 | action | place, heat | covered |
| n19 | action | pick_up, close | covered |
| n20 | action | turn, walk | covered |
| n21 | action | place | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s21 is represented
- Opaque-text spans: none
- Label-preserved spans: t2:s2 "oven" -> object_label::oven (label only; no sense resolved)
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): User requests a sequence of steps for putting bread in a trash can — via bread, trash_can, state_sliced, slice, knife
- [OK ] n2 (action): Put bread into a trash can — via bread, trash_can, place, state_sliced, knife
- [OK ] n3 (object): Bread — via bread, knife
- [OK ] n4 (object): Trash can — via trash_can, bread, object_label
- [OK ] n5 (action): Move to the left side of the oven — via microwave, turn, left_of, walk, counter, close
- [OK ] n6 (object): Oven — via bread, microwave, object_label
- [OK ] n7 (action): Pick up the knife from the counter — via knife, counter, pick_up, slice, state_sliced
- [OK ] n8 (object): Knife — via knife, bread, counter, state_sliced, object_label
- [OK ] n9 (object): Counter — via counter, bread, knife, object_label
- [OK ] n10 (action): Turn right and walk to the counter to the right of the oven — via counter, turn, microwave, walk, right_of
- [OK ] n11 (action): Slice the loaf of bread into pieces — via bread, slice, state_sliced, knife
- [OK ] n12 (object): Loaf of bread — via bread, knife, state_sliced
- [OK ] n13 (action): Put the knife down on the counter — via knife, counter, place, microwave, state_sliced
- [OK ] n14 (action): Pick up a slice of bread — via bread, slice, state_sliced, pick_up, knife
- [OK ] n15 (object): Slice of bread — via bread, state_sliced, slice, knife
- [OK ] n16 (action): Turn around and go to the microwave — via microwave, turn, walk, counter, close
- [OK ] n17 (object): Microwave — via microwave, bread, object_label
- [OK ] n18 (action): Place the bread into the microwave and cook it — via bread, microwave, place, knife, counter
- [OK ] n19 (action): Retrieve the bread from the microwave and close the door — via bread, microwave, close, pick_up, knife
- [OK ] n20 (action): Turn left and stop at the trash can — via trash_can, turn, left_of, counter
- [OK ] n21 (action): Throw the cooked bread into the trash can — via bread, trash_can, knife, state_sliced
