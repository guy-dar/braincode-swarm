# Translation 13-16 — success

- Translator ID: 13-16
- Batch: 13
- Dataset: alfred
- Item ID: alfred-trial_T20190908_224333_300425#0
- Glossary version: 19.0.0-draft.2-lexical-groups+g17 (sha 018146c57ffa)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T21:24:13Z
- Needs: 23 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Place a chilled mug in a cabinet.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Head left to the wall, turn left, hang a left at the microwave and walk to the island counter to the left.
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Pick up the white mug to the right of the loaf of bread on the counter.
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Turn right and walk to the black fridge on the right.
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Put the mug inside the fridge on the top shelf, chill it, remove it and close the door.
t2:s9 [AGENT] 5.
t2:s10 [AGENT] Turn around, walk forward and turn around to face the cabinets next to the fridge.
t2:s11 [AGENT] 6.
t2:s12 [AGENT] Open the lower left cabinet, put the chilled mug inside and close the door.
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT ObjectLabelMug
TASK ObjectLabelMug {
  ACTION turn(direction="left")
  ACTION walk(destination=object_label::wall)
  ACTION turn(direction="left")
  ACTION walk(destination=object_label::microwave)
  ACTION turn(direction="left")
  ACTION walk(destination=object_label::counter)
  TERM lexical_label(value=object_label::mug) -> lexical_label_2 : TERM
  TERM lexical_label(value=food_label::bread) -> lexical_label_3 : TERM
  TERM spatial_constraint(object=lexical_label_2, reference=lexical_label_3, relation=right_of) -> spatial_constraint_2 : TERM
  ACTION pick_up(target=object_label::mug, color=color_label::white, source=object_label::counter) -> object_label_mug_ref : REF[STRING]
  ACTION turn(direction="right")
  ACTION walk(destination=object_label::fridge)
  TERM lexical_label(value=object_label::fridge) -> lexical_label_4 : TERM
  ACTION open(target=lexical_label_4)
  ACTION place(target=object_label_mug_ref, destination=object_label::fridge, location=object_label::shelf, relation=in)
  ACTION chill(target=object_label_mug_ref, destination=object_label::fridge) -> object_label_mug_ref_2 : REF[STRING]
  ACTION remove(target=object_label_mug_ref_2, source=lexical_label_4)
  ACTION close(target=lexical_label_4)
  ACTION turn(direction="around")
  ACTION face(target=object_label::cabinet)
  TERM lexical_label(value=object_label::cabinet) -> lexical_label_5 : TERM
  ACTION open(target=lexical_label_5)
  ACTION place(target=object_label_mug_ref_2, destination=object_label::cabinet, relation=in)
  ACTION close(target=lexical_label_5)
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | place, chill | covered |
| n2 | action | place, in | covered |
| n3 | object | object_label::mug | label-preserved |
| n4 | constraint | chill | covered |
| n5 | object | object_label::cabinet | label-preserved |
| n6 | action | walk, turn | covered |
| n7 | object | object_label::microwave | label-preserved |
| n8 | object | object_label::counter | label-preserved |
| n9 | action | pick_up | covered |
| n10 | constraint | color_label::white | label-preserved |
| n11 | object | food_label::bread | label-preserved |
| n12 | constraint | spatial_constraint, right_of | covered |
| n13 | action | turn, walk | covered |
| n14 | object | object_label::fridge | label-preserved |
| n15 | constraint | color_label::black | label-preserved |
| n16 | action | place, in, shelf | covered |
| n17 | action | chill | covered |
| n18 | action | remove | covered |
| n19 | action | close | covered |
| n20 | action | turn, face | covered |
| n21 | action | open | covered |
| n22 | action | place, in | covered |
| n23 | action | close | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s12 is represented
- Opaque-text spans: none
- Label-preserved spans: t1:s1 "mug" → object_label::mug, t1:s1 "cabinet" → object_label::cabinet, t2:s2 "microwave" → object_label::microwave, t2:s2 "island counter" → object_label::counter, t2:s4 "white" → color_label::white, t2:s4 "bread" → food_label::bread, t2:s6 "fridge" → object_label::fridge, t2:s6 "black" → color_label::black
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): request to place a chilled mug in a cabinet — via mug, cabinet, fridge, counter, chill, place
- [OK ] n2 (action): place an object inside a cabinet — via cabinet, in, shelf, place, fridge, counter, close, open, chill
- [OK ] n3 (object): mug — via mug, chill, object_label
- [OK ] n4 (constraint): mug must be chilled — via mug, chill, fridge
- [OK ] n5 (object): cabinet — via cabinet, shelf, fridge, counter, object_label
- [OK ] n6 (action): navigate left past wall and microwave toward the island counter — via counter, microwave, wall, fridge, walk, turn
- [OK ] n7 (object): microwave — via microwave, fridge, counter, object_label
- [OK ] n8 (object): island counter — via counter, cabinet, object_label
- [OK ] n9 (action): pick up the mug — via mug, pick_up
- [OK ] n10 (constraint): white color — via color_label, wall
- [OK ] n11 (object): loaf of bread — via bread, food_label
- [OK ] n12 (constraint): located to the right of the bread on the counter — via counter, bread, right_of
- [OK ] n13 (action): turn right and walk to the fridge — via fridge, walk, turn, right_of, counter, cabinet
- [OK ] n14 (object): fridge — via fridge, cabinet, microwave, shelf, object_label
- [OK ] n15 (constraint): black color — via color_label, wall, right_of
- [OK ] n16 (action): put the mug on the top shelf inside the fridge — via fridge, mug, shelf, place, in, counter, cabinet, remove
- [OK ] n17 (action): chill the mug — via mug, chill
- [OK ] n18 (action): remove the chilled mug from the fridge — via fridge, mug, remove, chill, cabinet
- [OK ] n19 (action): close the fridge door — via fridge, close, cabinet, open, microwave, shelf
- [OK ] n20 (action): turn around and face the cabinets next to the fridge — via fridge, cabinet, turn, face, shelf, counter, close, microwave, wall
- [OK ] n21 (action): open the lower left cabinet — via cabinet, open, counter, fridge, close, microwave, shelf, turn
- [OK ] n22 (action): place the chilled mug inside the cabinet — via mug, cabinet, chill, place, in, fridge, counter, remove
- [OK ] n23 (action): close the cabinet door — via close, cabinet, open, shelf, fridge, counter, microwave, wall, in
