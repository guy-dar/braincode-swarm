# Translation 11-24 — success

- Translator ID: 11-24
- Batch: 11
- Dataset: alfred
- Item ID: alfred-trial_T20190909_013018_393040#1
- Glossary version: 19.0.0-draft.2-lexical-groups+g15 (sha d6391191e501)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T20:23:51Z
- Needs: 22 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Place a kettle inside the cabinet.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Turn right and walk to the side of the table where the kettle is.
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Grab the kettle on the table.
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Carrying the kettle, turn left and walk to the counter to the left.
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Place the kettle inside the cabinet.
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT ObjectLabelKettle
TASK ObjectLabelKettle {
  ACTION turn(direction="right")
  ACTION walk(destination=object_label::table)
  ACTION pick_up(target=object_label::kettle, source=object_label::table) -> object_label_kettle_ref : REF[STRING]
  ACTION turn(direction="left")
  ACTION walk(destination=object_label::counter, relation=left_of)
  ACTION place(target=object_label_kettle_ref, destination=object_label::cabinet, relation=in)
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | Task | covered |
| n2 | action | place | covered |
| n3 | object | object_label::kettle | label-preserved |
| n4 | object | object_label::cabinet | label-preserved |
| n5 | temporal | Task | covered |
| n6 | action | turn | covered |
| n7 | action | walk | covered |
| n8 | object | object_label::table | label-preserved |
| n9 | object | object_label::kettle | label-preserved |
| n10 | temporal | Task | covered |
| n11 | action | pick_up | covered |
| n12 | object | object_label::kettle | label-preserved |
| n13 | object | object_label::table | label-preserved |
| n14 | temporal | Task | covered |
| n15 | action | pick_up, walk | covered |
| n16 | action | turn | covered |
| n17 | action | walk, left_of | covered |
| n18 | object | object_label::counter | label-preserved |
| n19 | temporal | Task | covered |
| n20 | action | place, in | covered |
| n21 | object | object_label::kettle | label-preserved |
| n22 | object | object_label::cabinet | label-preserved |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s8 is represented
- Opaque-text spans: none
- Label-preserved spans: t1:s1 "kettle" → object_label::kettle, "cabinet" → object_label::cabinet; t2:s2 "table" → object_label::table, "kettle" → object_label::kettle; t2:s4 "kettle" → object_label::kettle, "table" → object_label::table; t2:s6 "counter" → object_label::counter; t2:s8 "kettle" → object_label::kettle, "cabinet" → object_label::cabinet
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): User instructs to place a kettle inside the cabinet — via cabinet, in, counter, place
- [OK ] n2 (action): Place an object inside a cabinet — via cabinet, place, in, counter
- [LABEL] n3 (object): kettle — via object_label
- [OK ] n4 (object): cabinet — via cabinet, counter, object_label
- [DECL] n5 (temporal): First step in a sequence
- [OK ] n6 (action): Turn right — via turn, walk, left_of
- [OK ] n7 (action): Walk to the side of the table where the kettle is located — via table, walk, counter
- [OK ] n8 (object): table — via table, counter, object_label
- [LABEL] n9 (object): kettle — via object_label
- [OK ] n10 (temporal): Second step in a sequence — via left_of
- [OK ] n11 (action): Grab the kettle on the table — via table, pick_up, counter
- [LABEL] n12 (object): kettle — via object_label
- [OK ] n13 (object): table — via table, counter, object_label
- [OK ] n14 (temporal): Third step in a sequence — via left_of
- [DECL] n15 (action): Carry the kettle while moving
- [OK ] n16 (action): Turn left — via turn, left_of, walk
- [OK ] n17 (action): Walk to the counter on the left — via counter, walk, left_of, cabinet, table, turn
- [OK ] n18 (object): counter — via counter, table, cabinet, object_label
- [OK ] n19 (temporal): Fourth step in a sequence — via left_of
- [OK ] n20 (action): Place the kettle inside the cabinet — via cabinet, place, in, counter
- [LABEL] n21 (object): kettle — via object_label
- [OK ] n22 (object): cabinet — via cabinet, counter, object_label

Needs covered by an open-group label only (report as label-preserved): n3; n9; n12; n21
