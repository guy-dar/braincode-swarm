# Translation 14-28 — success

- Translator ID: 14-28
- Batch: 14
- Dataset: alfred
- Item ID: alfred-trial_T20190909_151718_645545#2
- Glossary version: 19.0.0-draft.2-lexical-groups+g19 (sha be5d8379f7a6)
- Model: vertex-proxy/gemini-flash
- Translated at: 2026-10-04T22:05:56Z
- Needs: 28 (decomposition: llm (prefetched))

## Original data item

```text
t1:s1 [USER] Put a cold potato in the microwave.

t2:s1 [AGENT] 1.
t2:s2 [AGENT] Turn around and walk toward the sink, then turn right and walk to the microwave.
t2:s3 [AGENT] 2.
t2:s4 [AGENT] Pick up the potato on the counter to the right of the microwave.
t2:s5 [AGENT] 3.
t2:s6 [AGENT] Turn around and walk back toward the table, then turn right and walk to the refrigerator.
t2:s7 [AGENT] 4.
t2:s8 [AGENT] Put the potato in the refrigerator and leave it until chilled, then take it out.
t2:s9 [AGENT] 5.
t2:s10 [AGENT] Turn around and walk back to the microwave.
t2:s11 [AGENT] 6.
t2:s12 [AGENT] Put the potato in the microwave.
```

## Translation

Status: success
Mode: REQUEST

## BrainCode

```braincode
MODE REQUEST
ENTRYPOINT FoodLabelPotato
TASK FoodLabelPotato {
  ACTION turn(direction="around")
  ACTION walk(destination=sink)
  ACTION turn(direction="right")
  ACTION walk(destination=microwave)
  ACTION pick_up(target=food_label::potato, source=counter) -> food_label_potato_ref : REF[STRING]
  ACTION turn(direction="around")
  ACTION walk(destination=table)
  ACTION turn(direction="right")
  ACTION walk(destination=fridge)
  ACTION chill(target=food_label_potato_ref, destination=fridge) -> food_label_potato_ref_2 : REF[STRING]
  ACTION turn(direction="around")
  ACTION walk(destination=microwave)
  ACTION place(target=food_label_potato_ref_2, destination=microwave, relation=in)
}
```

## Needs coverage

| need | kind | expressed by | status |
|---|---|---|---|
| n1 | speech_act | chill, microwave, place | covered |
| n2 | action | in, place | covered |
| n3 | object | food_label::potato | label-preserved |
| n4 | constraint | chill | covered |
| n5 | object | microwave | covered |
| n6 | action | turn | covered |
| n7 | action | sink, walk | covered |
| n8 | object | sink | covered |
| n9 | action | turn | covered |
| n10 | action | microwave, walk | covered |
| n11 | object | microwave | covered |
| n12 | action | pick_up | covered |
| n13 | object | food_label::potato | label-preserved |
| n14 | object | counter | covered |
| n15 | action | turn | covered |
| n16 | action | table, walk | covered |
| n17 | object | table | covered |
| n18 | action | turn | covered |
| n19 | action | fridge, walk | covered |
| n20 | object | fridge | covered |
| n21 | action | chill, fridge | covered |
| n22 | temporal | chill | covered |
| n23 | action | chill, fridge | covered |
| n24 | action | turn | covered |
| n25 | action | microwave, walk | covered |
| n26 | action | microwave, place | covered |
| n27 | object | food_label::potato | label-preserved |
| n28 | object | microwave | covered |

## Translation report

- Input kind: conversation
- Coverage status: complete
- Source-span coverage: every segment t1:s1–t2:s12 is represented.
- Opaque-text spans: none
- Label-preserved spans: t1:s1 "potato" → food_label::potato (label only; no sense resolved); t2:s4 "potato" → food_label::potato (label only; no sense resolved); t2:s12 "potato" → food_label::potato (label only; no sense resolved)
- Missing constructs: none
- Unresolved ambiguities: none
- Check: `rag check` reported 0 unresolved needs and 0 unknown symbols

## Host check

- [OK ] n1 (speech_act): request to put a cold potato in the microwave — via microwave, fridge, place
- [OK ] n2 (action): put an object inside another — via place, in, chill
- [LABEL] n3 (object): potato — via food_label
- [OK ] n4 (constraint): state must be cold or chilled — via chill
- [OK ] n5 (object): microwave — via microwave, fridge, counter
- [OK ] n6 (action): turn around — via turn
- [OK ] n7 (action): walk toward the sink — via sink, walk, counter, fridge
- [OK ] n8 (object): sink — via sink, counter
- [OK ] n9 (action): turn right — via turn
- [OK ] n10 (action): walk to the microwave — via microwave, walk, fridge, counter
- [OK ] n11 (object): microwave — via microwave, fridge, counter
- [OK ] n12 (action): pick up the potato — via pick_up
- [LABEL] n13 (object): potato — via food_label
- [OK ] n14 (object): counter to the right of the microwave — via microwave, counter, fridge
- [OK ] n15 (action): turn around — via turn
- [OK ] n16 (action): walk back toward the table — via walk, table, counter
- [OK ] n17 (object): table — via table, counter
- [OK ] n18 (action): turn right — via turn
- [OK ] n19 (action): walk to the refrigerator — via walk, fridge, counter
- [OK ] n20 (object): refrigerator — via fridge, microwave, counter
- [OK ] n21 (action): put the potato in the refrigerator — via fridge, place, microwave
- [OK ] n22 (temporal): leave until chilled before taking out — via chill
- [OK ] n23 (action): take the potato out of the refrigerator — via fridge, pick_up
- [OK ] n24 (action): turn around — via turn
- [OK ] n25 (action): walk back to the microwave — via microwave, walk, fridge, counter
- [OK ] n26 (action): put the potato in the microwave — via microwave, place, fridge
- [LABEL] n27 (object): potato — via food_label
- [OK ] n28 (object): microwave — via microwave, fridge, counter

Needs covered by an open-group label only (report as label-preserved): n3; n13; n27
